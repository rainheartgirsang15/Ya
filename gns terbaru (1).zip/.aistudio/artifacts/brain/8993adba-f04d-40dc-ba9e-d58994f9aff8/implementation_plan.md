# Mode Tester & Simulasi Ikat GPS Gojek Driver di Emulator

Rencana ini menghadirkan fitur **Tester Simulator Driver** di dalam aplikasi serta rangkaian **pengujian unit otomatis (JVM)** agar alur pengikatan GPS ke Gojek Driver (GoPartner), Grab Driver, Shopee Driver, Maxim Driver, dan inDrive dapat diuji tuntas langsung di *streaming emulator* maupun lingkungan lokal meskipun aplikasi GoPartner belum terpasang secara bawaan di emulator.

---

### Tinjauan Pengguna & Keputusan Utama

> [!IMPORTANT]
> Emulator *streaming* berbasis AOSP standar tidak membawa aplikasi Play Store pihak ketiga seperti GoPartner (`com.gojek.partner`) secara bawaan, dan lingkungan pengembangan agen tidak memiliki akses ADB langsung ke emulator. Seluruh pertanyaan klarifikasi sebelumnya dilewati, sehingga rencana ini menggunakan pendekatan default yang direkomendasikan di bawah ini.

- **Mode Pengujian Ganda (Default Terpilih)**: Menggabungkan **Mode Tester Simulator Driver** di UI aplikasi (untuk dicoba langsung di *streaming emulator*) dengan **Suite Unit Test JVM** (untuk validasi logika deteksi paket secara otomatis).
- **Perilaku Saat Gojek Driver Tidak Terpasang**: Saat *Mode Tester Simulator* diaktifkan, menekan tombol **Gojek Driver** (atau salah satu dari 4 aplikasi driver lainnya) akan menjalankan alur pengikatan nyata (menyimpan aplikasi prioritas, menyalakan *Background GPS Lock*, dan menguji notifikasi) lalu membuka lembar **Pratinjau Koneksi Driver (Simulasi)** alih-alih gagal membuka *Intent*.
- **Cakupan Platform Driver**: Mencakup seluruh 5 ekosistem driver (**Gojek Driver**, **Grab Driver**, **Shopee Driver**, **Maxim Driver**, dan **inDrive**), dengan fokus uji utama pada **Gojek Driver (GoPartner)**.

---

### 1. Gambaran Umum & Konsep Inti

- **Apa yang Dilakukan**: Menambahkan sakelar opsional **Mode Tester Simulator** pada dialog **Panduan Driver** dan kartu **Ikat GPS ke Aplikasi Prioritas**, lengkap dengan banner penanda simulasi yang mencolok serta panel diagnostik status deteksi paket nyata versus simulasi.
- **Target Pengguna**: Pengemudi dan penguji yang ingin memverifikasi fungsi pengikatan GPS, kunci latar belakang, notifikasi kunci GPS, serta kelayakan sinyal untuk Gojek Driver dan aplikasi ojol lainnya langsung di emulator bersih.
- **Nilai Utama**: Pengguna dapat membuktikan bahwa alur ikat aplikasi, pembaruan *foreground notification* (tombol cepat `Buka GoPartner`), dan penyaluran telemetri GNSS bekerja utuh di emulator tanpa harus mengunduh APK GoPartner dari Play Store terlebih dahulu.

---

### 2. Pengalaman Pengguna & Desain Visual

- **Alur Pengguna (Step-by-Step)**:
  1. Pada tab **Fix**, pengguna membuka kartu **Ikat GPS ke Aplikasi Prioritas** atau mengetuk **Panduan Driver**.
  2. Di bagian atas dialog **Panduan Driver**, pengguna melihat status deteksi asli dari sistem Android untuk ke-5 aplikasi driver (pada emulator bersih, semuanya akan tampil *Belum terpasang*).
  3. Pengguna mengaktifkan sakelar **"Mode Tester Simulator (Emulator)"**.
  4. Banner peringatan kuning/cyan (**"MODE SIMULASI TESTER AKTIF"**) langsung muncul di kartu Prioritas agar selalu terbedakan jelas dari kondisi perangkat asli, dan ke-5 tombol cepat driver (**Gojek Driver**, **Grab Driver**, **Shopee Driver**, **Maxim Driver**, **inDrive**) berubah status menjadi siap diuji (`Simulator`).
  5. Saat pengguna mengetuk **Gojek Driver**:
     - Aplikasi menyimpan `com.gojek.partner` sebagai aplikasi prioritas aktif.
     - Layanan latar belakang **Kunci GPS Latar Belakang** otomatis menyala (jika belum aktif) dan notifikasi status latar belakang menampilkan tombol aksi **Buka GoPartner**.
     - Karena `com.gojek.partner` adalah entri simulator (bukan APK nyata di emulator), aplikasi membuka modal **Pratinjau Koneksi Driver (Simulasi)** yang menampilkan secara *real-time*: identitas paket target (`com.gojek.partner`), status kunci (`3D/2D/Searching`), tingkat kekuatan sinyal, akurasi (`±m`), jumlah satelit aktif, koordinat, kecepatan, serta status optimasi baterai.
  6. Pengguna dapat menekan **Tutup Pratinjau** atau mematikan **Mode Tester Simulator** kapan saja untuk kembali ke deteksi paket perangkat asli 100%.
- **Identitas Visual & Material 3**:
  - Mempertahankan tema kokpit gelap (*Cockpit Dark*) dan *Daylight* menggunakan token warna tema Material 3 yang sudah ada (`SignalEmerald` untuk sinyal siap, `TelemetryCyan` untuk lencana simulator, `AmberSearch` untuk peringatan mode simulasi dan baterai).
  - Seluruh kontrol tombol dan sakelar memiliki tinggi sentuh minimal `48.dp` serta `testTag` konsisten untuk aksesibilitas dan pengujian Compose.
- **Umpan Balik Interaktif**:
  - Transisi halus (`AnimatedVisibility`) untuk banner indikator **Mode Simulasi Tester Aktif**.
  - Indikator status *real-time* di dalam modal pratinjau agar pengguna melihat telemetri GNSS terus mengalir saat simulasi ikat driver berjalan.

---

### 3. Keputusan Produk & Pertimbangan Teknis

- **Keputusan 1: Pemisahan Ketat Data Nyata vs Mode Simulasi Tester**
  - *Pendekatan*: Mode simulator hanya aktif jika dinyalakan secara eksplisit oleh pengguna, tidak tersimpan permanen memblokir deteksi asli saat dimatikan, dan wajib menampilkan lencana **"MODE SIMULASI TESTER"** di UI.
  - *Alasan*: Mematuhi prinsip integrasi nyata—pengguna di HP asli tidak pernah tertipu oleh data palsu, sementara pengujian di emulator tetap berjalan lancar.
  - *Alternatif yang Ditolak*: Menganggap Gojek Driver selalu terpasang secara *hardcoded* (ditolak karena membingungkan pengguna nyata ketika `startActivity` gagal).
- **Keputusan 2: Pengujian Otomatis via JVM Unit Test (Tanpa Ketergantungan Jaringan Robolectric)**
  - *Pendekatan*: Menambahkan suite unit test murni di JVM untuk memverifikasi pencocokan daftar paket ke-5 platform driver (`DriverPlatform`), urutan prioritas paket Gojek Driver (`com.gojek.partner` diutamakan atas varian lama), serta logika pembentukan *Intent*.
  - *Alasan*: Lingkungan *sandbox* *offline* memblokir unduhan artefak SDK Robolectric dari Maven jarak jauh, sedangkan unit test JVM standar berjalan cepat (~detik) dan deterministik setiap kali dikompilasi.

---

### 4. Arsitektur Teknis & Strategi Data

```
┌──────────────────────────────────────────────────────────────────────┐
│                         UI Dashboard & Dialogs                       │
│  ┌──────────────────────────────┐  ┌──────────────────────────────┐  │
│  │    PriorityBindingCard       │  │   DriverGuide & Preview      │  │
│  │ • Banner Mode Simulasi       │  │ • Sakelar Mode Tester        │  │
│  │ • 5 Tombol Cepat Driver      │  │ • Status Deteksi Nyata/Sim   │  │
│  │ • Tombol Buka Aplikasi       │  │ • Modal Pratinjau Telemetri  │  │
│  └──────────────┬───────────────┘  └──────────────┬───────────────┘  │
└─────────────────┼─────────────────────────────────┼──────────────────┘
                  │ aksi pengguna & aliran state    │
                  ▼                                 ▼
┌──────────────────────────────────────────────────────────────────────┐
│                            GnssViewModel                             │
│  • State: isDriverTesterMode (MutableStateFlow<Boolean>)             │
│  • Gabungkan aplikasi terpasang nyata + entri simulator jika aktif   │
│  • Arahkan aksi buka ke Intent nyata ATAU Modal Pratinjau Simulasi   │
└─────────────────┬─────────────────────────────────┬──────────────────┘
                  │                                 │
                  ▼                                 ▼
┌──────────────────────────────────┐  ┌────────────────────────────────┐
│       PriorityAppHelper          │  │    GnssLockService & Notifier  │
│ • Deteksi Paket Nyata (<queries>)│  │ • Foreground GPS Watchdog      │
│ • Generator Entri Tester 5 Driver│  │ • Aksi Notifikasi Target App   │
└──────────────────────────────────┘  └────────────────────────────────┘
```

- **Model Data & State**:
  - Penambahan flag `isSimulated: Boolean = false` pada `PriorityAppInfo` untuk membedakan secara tegas aplikasi hasil kueri `PackageManager` dari aplikasi simulator tester.
  - `GnssViewModel` memelihara state `driverTesterMode` (default `false`) dan `simulatedPreviewApp: PriorityAppInfo?` untuk menampilkan modal pratinjau langsung saat entri simulasi dijalankan.
- **Pemetaan Interaksi**:
  - Menyalakan **Mode Tester Simulator** menggabungkan daftar paket nyata dengan daftar simulasi ke-5 driver tanpa menimpa aplikasi nyata yang sudah terpasang.
  - Memilih **Gojek Driver** dalam mode simulasi memicu `setPriorityApp("com.gojek.partner")`, memanggil `ensureBackgroundLockEnabled()`, memperbarui notifikasi *foreground*, dan membuka modal **Pratinjau Koneksi Driver (Simulasi)** dengan pembacaan `telemetryState` langsung.
  - Mengetuk **Reset / Matikan Mode Tester** membersihkan entri simulasi dan menyegarkan ulang kueri paket sistem asli.
