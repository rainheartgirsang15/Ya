# Artefak Build GNSS Fix (APK)

File APK debug terbaru (`GNSS-Fix-debug.apk`, ukuran ~19 MB) telah diperbarui dan disalin ke direktori artifacts sehingga siap dipasang di perangkat Android.

- **Versi Build**: Debug APK terbaru (tanpa mode simulasi)
- **SHA-256**: `cfb0df33f4c6e64487302109398c6d825453d09d975306ad98a8fa9c294bfbe8`

## Fitur yang Tersedia di Build Ini
- **Penguat Sinyal GNSS Prioritas Driver**: Mode *Full-Tracking* berkelanjutan (Android 12+), injeksi A-GPS otomatis saat online, filter anti-loncat agar koordinat tidak melompat ke lokasi seluler/Wi-Fi kasar, indikator tingkat kekuatan sinyal (*Sangat Kuat*, *Kuat*, *Sedang*, *Lemah*), serta *watchdog* latar belakang setiap 10 detik.
- **Ikat GPS ke 5 Aplikasi Driver**: Tombol ikat cepat langsung untuk **Gojek Driver** (`com.gojek.partner` + varian), **Grab Driver** (`com.grabtaxi.driver2`), **Shopee Driver** (`com.shopee.foody.driver.id` / `com.shopee.fms`), **Maxim Driver** (`com.taxsee.driver`), dan **inDrive** (`sinet.startup.inDriver`), plus pengingat status baterai **Tidak Dibatasi**.
- **GNSS Fix & Background Lock**: Pelacakan multi-konstelasi (`GPS`, `GLONASS`, `Galileo`, `BeiDou`, `QZSS`, `NavIC`, `SBAS`), *Boost A-GPS*, *Cold Reset*, dan layanan latar belakang (*Foreground Service*).
- **Notifikasi GPS Terkunci**: Notifikasi prioritas tinggi saat posisi 2D/3D terkunci lengkap dengan tombol cepat buka aplikasi driver prioritas.
- **Speedometer Melingkar**: Pengukur kecepatan gerak *real-time* dalam satuan `km/h` atau `mph` beserta rekor kecepatan puncak.
- **Skyplot, Sinyal CN0, Kompas & NMEA 0183**: Peta langit satelit, grafik kekuatan sinyal CN0, kompas presisi dengan kalibrasi angka-8 (jika HP mendukung magnetometer), dan aliran kalimat NMEA mentah.

## Cara Mengunduh APK di AI Studio / GitHub
- **Menu Settings AI Studio**: Gunakan menu **Settings** di pojok kanan atas AI Studio untuk mengekspor APK/AAB atau mengunduh paket proyek.
- **GitHub Actions**: Saat Anda *push* ke repositori GitHub, *workflow* `.github/workflows/build-apk.yml` otomatis membangun dan mengunggah artefak **`GNSS-Fix-debug-apk`**.
