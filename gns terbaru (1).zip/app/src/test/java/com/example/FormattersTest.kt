package com.example

import com.example.model.Constellation
import com.example.model.CoordFormat
import com.example.model.DopMetrics
import com.example.model.NmeaType
import com.example.model.SpeedUnit
import com.example.ui.components.selectSpeedScaleMax
import com.example.util.Formatters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class FormattersTest {

    @Test
    fun formatCoordinate_formatsAllCoordinateModes() {
        val lat = -6.208763
        val lon = 106.845599

        assertEquals("6.208763° S", Formatters.formatCoordinate(lat, isLatitude = true, CoordFormat.DECIMAL_DEGREES))
        assertEquals("106.845599° E", Formatters.formatCoordinate(lon, isLatitude = false, CoordFormat.DECIMAL_DEGREES))
        assertEquals("6° 12' 31.55\" S", Formatters.formatCoordinate(lat, isLatitude = true, CoordFormat.DMS))
        assertEquals("106° 50.736' E", Formatters.formatCoordinate(lon, isLatitude = false, CoordFormat.DDM))
    }

    @Test
    fun parseNmeaGsa_extractsDopAndFixMode() {
        val gsa = "\$GNGSA,A,3,03,06,12,17,19,,,,,,,,1.9,1.1,1.5*2B"
        val dop = Formatters.parseNmeaGsa(gsa, DopMetrics())
        assertEquals(3, dop.fixMode)
        assertEquals(1.9f, dop.pdop!!, 0.01f)
        assertEquals(1.1f, dop.hdop!!, 0.01f)
        assertEquals(1.5f, dop.vdop!!, 0.01f)
    }

    @Test
    fun parseNmeaGga_extractsMslAndHdop() {
        val gga = "\$GNGGA,041230.00,0612.5258,S,10650.7359,E,1,12,0.9,24.5,M,-4.2,M,,*6A"
        val (msl, hdop) = Formatters.parseNmeaGgaMslAndHdop(gga)
        assertNotNull(msl)
        assertNotNull(hdop)
        assertEquals(24.5, msl!!, 0.01)
        assertEquals(0.9f, hdop!!, 0.01f)
        assertEquals(NmeaType.GGA, Formatters.classifyNmeaType(gga))
    }

    @Test
    fun classifyCarrierBand_detectsL1AndL5() {
        assertEquals("L1", Formatters.classifyCarrierBand(Constellation.GPS, 1575.42f))
        assertEquals("L5", Formatters.classifyCarrierBand(Constellation.GPS, 1176.45f))
        assertEquals("E5a", Formatters.classifyCarrierBand(Constellation.GALILEO, 1176.45f))
    }

    @Test
    fun speedConversionAndScale_computesKmhAndMph() {
        val tenMps = 10f
        assertEquals(36.0f, Formatters.convertSpeed(tenMps, SpeedUnit.KMH), 0.01f)
        assertEquals(22.3694f, Formatters.convertSpeed(tenMps, SpeedUnit.MPH), 0.01f)
        assertEquals("36.0 km/h", Formatters.formatSpeed(tenMps, SpeedUnit.KMH))
        assertEquals("22.4 mph", Formatters.formatSpeed(tenMps, SpeedUnit.MPH))

        assertEquals(60f, selectSpeedScaleMax(35f, SpeedUnit.KMH), 0.01f)
        assertEquals(120f, selectSpeedScaleMax(85f, SpeedUnit.KMH), 0.01f)
        assertEquals(40f, selectSpeedScaleMax(22f, SpeedUnit.MPH), 0.01f)
        assertEquals(80f, selectSpeedScaleMax(65f, SpeedUnit.MPH), 0.01f)
    }
}
