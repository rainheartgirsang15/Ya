package com.example

import com.example.data.DriverPlatform
import com.example.data.PriorityAppHelper
import com.example.model.PriorityAppInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PriorityAppHelperTest {

    @Test
    fun `matches all five supported driver apps when installed`() {
        val installed = listOf(
            PriorityAppInfo("com.gojek.partner", "GoPartner"),
            PriorityAppInfo("com.grabtaxi.driver2", "Grab Driver"),
            PriorityAppInfo("com.shopee.foody.driver.id", "ShopeeFood Driver"),
            PriorityAppInfo("com.taxsee.driver", "Taxsee Driver"),
            PriorityAppInfo("sinet.startup.inDriver", "inDrive"),
        )

        val matches = PriorityAppHelper.matchDriverPlatforms(installed)
        assertEquals(5, matches.size)
        assertTrue(matches.all { it.installedApp != null })
        assertEquals("GoPartner", matches.first { it.platform == DriverPlatform.GOJEK }.installedApp?.label)
        assertEquals("Grab Driver", matches.first { it.platform == DriverPlatform.GRAB }.installedApp?.label)
        assertEquals("ShopeeFood Driver", matches.first { it.platform == DriverPlatform.SHOPEE }.installedApp?.label)
        assertEquals("Taxsee Driver", matches.first { it.platform == DriverPlatform.MAXIM }.installedApp?.label)
        assertEquals("inDrive", matches.first { it.platform == DriverPlatform.INDRIVE }.installedApp?.label)
    }

    @Test
    fun `prefers GoPartner over legacy Gojek driver variants`() {
        val installed = listOf(
            PriorityAppInfo("com.gojek.driver", "Gojek Driver Legacy"),
            PriorityAppInfo("com.gojek.partner", "GoPartner"),
        )

        val matched = PriorityAppHelper.findGojekDriverApp(installed)
        assertNotNull(matched)
        assertEquals("com.gojek.partner", matched?.packageName)
    }

    @Test
    fun `supports Shopee Driver fallback packages`() {
        val installedFms = listOf(PriorityAppInfo("com.shopee.fms", "SPX Driver"))
        val matchFms = PriorityAppHelper.matchDriverPlatforms(installedFms)
            .first { it.platform == DriverPlatform.SHOPEE }

        assertEquals("com.shopee.fms", matchFms.installedApp?.packageName)
    }
}
