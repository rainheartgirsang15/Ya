package com.example.ui.components

import android.hardware.GeomagneticField
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CompassCalibration
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CompassAccuracy
import com.example.model.CompassState
import com.example.model.LocationFix
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.AmberSearch
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.TabularMonoStyle
import com.example.ui.theme.TelemetryCyan
import com.example.util.Formatters
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CompassScreen(
    compass: CompassState,
    locationFix: LocationFix?,
    onResampleCalibration: () -> Unit,
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier,
) {
    var showCalibrationDialog by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    val declinationDeg = remember(locationFix?.latitude, locationFix?.longitude, locationFix?.altitudeMeters) {
        locationFix?.let { fix ->
            runCatching {
                GeomagneticField(
                    fix.latitude.toFloat(),
                    fix.longitude.toFloat(),
                    (fix.altitudeMeters ?: 0.0).toFloat(),
                    System.currentTimeMillis(),
                ).declination
            }.getOrNull()
        }
    }

    val trueHeadingDeg = if (compass.azimuthDeg != null && declinationDeg != null) {
        ((compass.azimuthDeg + declinationDeg) + 360f) % 360f
    } else null

    val accuracyColor = compassAccuracyColor(compass.accuracy)
    val accuracyLabel = compassAccuracyText(compass.accuracy)
    val fieldUt = compass.magneticFieldMicroTesla
    val hasInterference = fieldUt != null && (fieldUt > 80f || fieldUt < 15f)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(contentPadding)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 760.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.compass_title),
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = compass.azimuthDeg?.let { Formatters.formatBearing(it) } ?: "—",
                        style = TabularMonoStyle.copy(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                        ),
                        color = accuracyColor,
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = accuracyColor.copy(alpha = 0.16f),
                ) {
                    Text(
                        text = compass.accuracy.name,
                        style = TabularMonoStyle.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                        color = accuracyColor,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    )
                }
            }

            // Compass Rose Dial Card
            Card(
                shape = MaterialTheme.shapes.extraLarge,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant,
                        shape = MaterialTheme.shapes.extraLarge,
                    ),
            ) {
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    val dialSize = if (maxWidth < 340.dp) maxWidth else 340.dp
                    CompassRoseCanvas(
                        azimuthDeg = compass.azimuthDeg ?: 0f,
                        pitchDeg = compass.pitchDeg ?: 0f,
                        rollDeg = compass.rollDeg ?: 0f,
                        accentColor = accuracyColor,
                        modifier = Modifier
                            .size(dialSize)
                            .aspectRatio(1f)
                            .testTag("compass_rose_canvas"),
                    )
                }
            }

            // Magnetic vs True North Readout
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                CompassMetricTile(
                    label = stringResource(R.string.compass_magnetic_heading),
                    value = Formatters.formatBearing(compass.azimuthDeg),
                    accent = TelemetryCyan,
                    modifier = Modifier.weight(1f),
                )
                CompassMetricTile(
                    label = stringResource(R.string.compass_true_heading),
                    value = Formatters.formatBearing(trueHeadingDeg),
                    subtitle = declinationDeg?.let {
                        String.format(
                            Locale.US,
                            "%s %+.1f°",
                            stringResource(R.string.compass_declination),
                            it,
                        )
                    },
                    accent = SignalEmerald,
                    modifier = Modifier.weight(1f),
                )
            }

            // Calibration & Magnetic Interference Card
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = accuracyColor.copy(alpha = 0.45f),
                        shape = MaterialTheme.shapes.large,
                    ),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.compass_accuracy_label),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                text = accuracyLabel,
                                style = MaterialTheme.typography.titleMedium,
                                color = accuracyColor,
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = stringResource(R.string.compass_field_strength),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                text = fieldUt?.let { String.format(Locale.US, "%.1f µT", it) } ?: "—",
                                style = TabularMonoStyle.copy(
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                ),
                                color = if (hasInterference) AmberSearch else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }

                    AnimatedVisibility(visible = hasInterference) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.WarningAmber,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                    modifier = Modifier.size(18.dp),
                                )
                                Text(
                                    text = stringResource(R.string.compass_interference_warn),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                )
                            }
                        }
                    }

                    Button(
                        onClick = { showCalibrationDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("calibrate_compass_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CompassCalibration,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.compass_calibrate_btn))
                    }
                }
            }
        }
    }

    if (showCalibrationDialog) {
        CompassCalibrationDialog(
            compass = compass,
            onResample = onResampleCalibration,
            onDismiss = { showCalibrationDialog = false },
        )
    }
}

@Composable
private fun CompassRoseCanvas(
    azimuthDeg: Float,
    pitchDeg: Float,
    rollDeg: Float,
    accentColor: Color,
    modifier: Modifier = Modifier,
) {
    val textMeasurer = rememberTextMeasurer()
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.65f)
    val subGridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.30f)
    val textColor = MaterialTheme.colorScheme.onSurface
    val subTextColor = MaterialTheme.colorScheme.onSurfaceVariant
    val surfaceColor = MaterialTheme.colorScheme.surfaceContainerLow

    Canvas(
        modifier = modifier.semantics {
            contentDescription = "Compass Rose ${azimuthDeg.toInt()} degrees"
        }
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val center = Offset(cx, cy)
        val outerR = (minOf(size.width, size.height) / 2f) * 0.88f

        // Background disc
        drawCircle(
            color = surfaceColor,
            radius = outerR,
            center = center,
        )
        drawCircle(
            color = gridColor,
            radius = outerR,
            center = center,
            style = Stroke(width = 2.dp.toPx()),
        )

        // Rotating Compass Dial
        rotate(degrees = -azimuthDeg, pivot = center) {
            val degTextStyle = TextStyle(
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize = 10.sp,
                color = subTextColor,
            )
            val cardinalStyle = TextStyle(
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = textColor,
            )

            for (deg in 0 until 360 step 5) {
                val rad = Math.toRadians(deg.toDouble() - 90.0)
                val cosA = cos(rad).toFloat()
                val sinA = sin(rad).toFloat()
                val isCardinal = deg % 90 == 0
                val isMajor = deg % 30 == 0
                val tickLen = when {
                    isCardinal -> 14.dp.toPx()
                    isMajor -> 10.dp.toPx()
                    else -> 5.dp.toPx()
                }
                val start = Offset(
                    x = cx + (outerR - tickLen) * cosA,
                    y = cy + (outerR - tickLen) * sinA,
                )
                val end = Offset(
                    x = cx + outerR * cosA,
                    y = cy + outerR * sinA,
                )
                drawLine(
                    color = when {
                        deg == 0 -> AlertCrimson
                        isMajor -> textColor.copy(alpha = 0.8f)
                        else -> subGridColor
                    },
                    start = start,
                    end = end,
                    strokeWidth = if (isMajor) 1.8.dp.toPx() else 1.dp.toPx(),
                )

                if (isCardinal) {
                    val label = when (deg) {
                        0 -> "N"
                        90 -> "E"
                        180 -> "S"
                        else -> "W"
                    }
                    val style = if (deg == 0) cardinalStyle.copy(color = AlertCrimson) else cardinalStyle
                    val measured = textMeasurer.measure(label, style)
                    val labelR = outerR - 27.dp.toPx()
                    drawText(
                        textLayoutResult = measured,
                        topLeft = Offset(
                            x = cx + labelR * cosA - measured.size.width / 2f,
                            y = cy + labelR * sinA - measured.size.height / 2f,
                        ),
                    )
                } else if (isMajor) {
                    val measured = textMeasurer.measure(deg.toString(), degTextStyle)
                    val labelR = outerR - 25.dp.toPx()
                    drawText(
                        textLayoutResult = measured,
                        topLeft = Offset(
                            x = cx + labelR * cosA - measured.size.width / 2f,
                            y = cy + labelR * sinA - measured.size.height / 2f,
                        ),
                    )
                }
            }
        }

        // Fixed Top Lubber Marker Triangle
        val markerTipY = cy - outerR - 2.dp.toPx()
        val markerPath = Path().apply {
            moveTo(cx, markerTipY + 10.dp.toPx())
            lineTo(cx - 7.dp.toPx(), markerTipY - 4.dp.toPx())
            lineTo(cx + 7.dp.toPx(), markerTipY - 4.dp.toPx())
            close()
        }
        drawPath(path = markerPath, color = accentColor)

        // Center Spirit Level Ring & Tilt Bubble
        val levelR = outerR * 0.24f
        drawCircle(
            color = subGridColor,
            radius = levelR,
            center = center,
            style = Stroke(width = 1.4.dp.toPx()),
        )
        drawLine(
            color = subGridColor,
            start = Offset(cx - levelR, cy),
            end = Offset(cx + levelR, cy),
            strokeWidth = 1.dp.toPx(),
        )
        drawLine(
            color = subGridColor,
            start = Offset(cx, cy - levelR),
            end = Offset(cx, cy + levelR),
            strokeWidth = 1.dp.toPx(),
        )

        val bubbleX = cx + ((rollDeg.coerceIn(-45f, 45f) / 45f) * (levelR * 0.78f))
        val bubbleY = cy - ((pitchDeg.coerceIn(-45f, 45f) / 45f) * (levelR * 0.78f))
        drawCircle(
            color = accentColor.copy(alpha = 0.3f),
            radius = 10.dp.toPx(),
            center = Offset(bubbleX, bubbleY),
        )
        drawCircle(
            color = accentColor,
            radius = 5.5.dp.toPx(),
            center = Offset(bubbleX, bubbleY),
        )
    }
}

@Composable
fun CompassCalibrationDialog(
    compass: CompassState,
    onResample: () -> Unit,
    onDismiss: () -> Unit,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "figure8_anim")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "figure8_phase",
    )

    val accColor = compassAccuracyColor(compass.accuracy)
    val accText = compassAccuracyText(compass.accuracy)
    val trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.compass_calibrate_title),
                style = MaterialTheme.typography.titleLarge,
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp),
                ) {
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val ampX = size.width * 0.36f
                    val ampY = size.height * 0.34f

                    val path = Path()
                    val steps = 80
                    for (i in 0..steps) {
                        val t = (i.toFloat() / steps) * (2.0 * Math.PI)
                        val x = cx + (ampX * sin(t)).toFloat()
                        val y = cy + (ampY * sin(2.0 * t)).toFloat()
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(
                        path = path,
                        color = trackColor,
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
                    )

                    val orbX = cx + (ampX * sin(phase.toDouble())).toFloat()
                    val orbY = cy + (ampY * sin(2.0 * phase.toDouble())).toFloat()
                    drawCircle(
                        color = accColor.copy(alpha = 0.25f),
                        radius = 13.dp.toPx(),
                        center = Offset(orbX, orbY),
                    )
                    drawCircle(
                        color = accColor,
                        radius = 7.dp.toPx(),
                        center = Offset(orbX, orbY),
                    )
                }

                Text(
                    text = stringResource(R.string.compass_calibrate_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column {
                            Text(
                                text = stringResource(R.string.compass_accuracy_label),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                text = accText,
                                style = MaterialTheme.typography.labelLarge,
                                color = accColor,
                            )
                        }
                        Text(
                            text = compass.magneticFieldMicroTesla?.let {
                                String.format(Locale.US, "%.1f µT", it)
                            } ?: "—",
                            style = TabularMonoStyle.copy(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                            ),
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                modifier = Modifier.testTag("compass_calibrate_done_button"),
            ) {
                Text(stringResource(R.string.compass_done_btn))
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onResample,
                modifier = Modifier.testTag("compass_resample_button"),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(stringResource(R.string.compass_rescan_btn))
            }
        },
    )
}

@Composable
private fun CompassMetricTile(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier.border(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant,
            shape = MaterialTheme.shapes.medium,
        ),
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = TabularMonoStyle.copy(
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                ),
                color = accent,
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun compassAccuracyColor(accuracy: CompassAccuracy): Color = when (accuracy) {
    CompassAccuracy.HIGH -> SignalEmerald
    CompassAccuracy.MEDIUM -> TelemetryCyan
    CompassAccuracy.LOW -> AmberSearch
    CompassAccuracy.UNRELIABLE -> AlertCrimson
}

@Composable
fun compassAccuracyText(accuracy: CompassAccuracy): String = when (accuracy) {
    CompassAccuracy.HIGH -> stringResource(R.string.compass_acc_high)
    CompassAccuracy.MEDIUM -> stringResource(R.string.compass_acc_medium)
    CompassAccuracy.LOW -> stringResource(R.string.compass_acc_low)
    CompassAccuracy.UNRELIABLE -> stringResource(R.string.compass_acc_unreliable)
}
