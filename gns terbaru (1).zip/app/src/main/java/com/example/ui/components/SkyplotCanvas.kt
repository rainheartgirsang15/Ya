package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.SatelliteAlt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CompassState
import com.example.model.Constellation
import com.example.model.FixState
import com.example.model.GnssTelemetryState
import com.example.model.SatelliteInfo
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.TabularMonoStyle
import java.util.Locale
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SkyplotScreen(
    telemetry: GnssTelemetryState,
    selectedSatelliteKey: String?,
    onSelectSatellite: (String?) -> Unit,
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier,
    compass: CompassState = CompassState(),
    compassAlignEnabled: Boolean = false,
    onToggleCompassAlign: () -> Unit = {},
) {
    val scrollState = rememberScrollState()
    val selectedSat = telemetry.satellites.find { it.key == selectedSatelliteKey }
    val canAlignCompass = compass.isSupported && compass.azimuthDeg != null
    val rotationDeg = if (compassAlignEnabled && canAlignCompass) {
        -(compass.azimuthDeg ?: 0f)
    } else {
        0f
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(contentPadding)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 760.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.skyplot_title),
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = stringResource(R.string.skyplot_subtitle),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (compass.isSupported) {
                        FilterChip(
                            selected = compassAlignEnabled,
                            onClick = onToggleCompassAlign,
                            enabled = canAlignCompass,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Rounded.Explore,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                )
                            },
                            label = {
                                Text(
                                    text = stringResource(R.string.compass_align_skyplot),
                                    style = MaterialTheme.typography.labelMedium,
                                )
                            },
                            modifier = Modifier.testTag("skyplot_compass_align_chip"),
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                    ) {
                        Text(
                            text = "${telemetry.usedSatelliteCount}/${telemetry.visibleSatelliteCount}",
                            style = TabularMonoStyle.copy(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                            ),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        )
                    }
                }
            }

            // Radar Skyplot Card
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant,
                        shape = MaterialTheme.shapes.large,
                    ),
            ) {
                BoxWithConstraints(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    val maxPlotSize = if (maxWidth < 400.dp) maxWidth else 400.dp
                    SkyplotRadarCanvas(
                        satellites = telemetry.satellites,
                        fixState = telemetry.fixState,
                        selectedKey = selectedSatelliteKey,
                        onSelectSatellite = onSelectSatellite,
                        rotationDeg = rotationDeg,
                        modifier = Modifier
                            .size(maxPlotSize)
                            .aspectRatio(1f)
                            .testTag("skyplot_canvas"),
                    )
                }
            }

            // Selected satellite detail card
            AnimatedVisibility(visible = selectedSat != null) {
                selectedSat?.let { sat ->
                    SelectedSatelliteCard(
                        satellite = sat,
                        onDismiss = { onSelectSatellite(null) },
                    )
                }
            }

            // Constellation Legend Strip
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant,
                        shape = MaterialTheme.shapes.medium,
                    ),
            ) {
                FlowRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    val primaryConstellations = listOf(
                        Constellation.GPS,
                        Constellation.GLONASS,
                        Constellation.GALILEO,
                        Constellation.BEIDOU,
                        Constellation.QZSS,
                        Constellation.IRNSS,
                        Constellation.SBAS,
                    )
                    primaryConstellations.forEach { constellation ->
                        val allForConst = telemetry.satellites.filter { it.constellation == constellation }
                        val usedCount = allForConst.count { it.usedInFix }
                        val totalCount = allForConst.size
                        ConstellationPill(
                            constellation = constellation,
                            usedCount = usedCount,
                            totalCount = totalCount,
                        )
                    }
                }
            }

            if (telemetry.satellites.isEmpty()) {
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SatelliteAlt,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                        )
                        Text(
                            text = stringResource(R.string.skyplot_empty),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SkyplotRadarCanvas(
    satellites: List<SatelliteInfo>,
    fixState: FixState,
    selectedKey: String?,
    onSelectSatellite: (String?) -> Unit,
    modifier: Modifier = Modifier,
    rotationDeg: Float = 0f,
) {
    val textMeasurer = rememberTextMeasurer()
    val infiniteTransition = rememberInfiniteTransition(label = "skyplot_sweep")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "sweep_angle",
    )

    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)
    val subGridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.28f)
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant
    val primaryTextColor = MaterialTheme.colorScheme.onSurface
    val primaryColor = MaterialTheme.colorScheme.primary
    val surfaceColor = MaterialTheme.colorScheme.surfaceContainerLowest
    val isSearching = fixState == FixState.SEARCHING

    Canvas(
        modifier = modifier
            .onSizeChanged { canvasSize = it }
            .semantics { contentDescription = "GNSS Satellite Skyplot" }
            .pointerInput(satellites, canvasSize, rotationDeg) {
                detectTapGestures { tapOffset ->
                    if (canvasSize.width == 0 || canvasSize.height == 0) return@detectTapGestures
                    val w = canvasSize.width.toFloat()
                    val h = canvasSize.height.toFloat()
                    val cx = w / 2f
                    val cy = h / 2f
                    val maxR = (minOf(w, h) / 2f) * 0.84f
                    val hitRadiusPx = 28.dp.toPx()

                    // Inverse-rotate tap offset around center when skyplot is compass-aligned
                    val invRad = Math.toRadians(-rotationDeg.toDouble())
                    val cosInv = cos(invRad).toFloat()
                    val sinInv = sin(invRad).toFloat()
                    val dx = tapOffset.x - cx
                    val dy = tapOffset.y - cy
                    val unrotatedTapX = cx + (dx * cosInv - dy * sinInv)
                    val unrotatedTapY = cy + (dx * sinInv + dy * cosInv)

                    var closestKey: String? = null
                    var closestDist = Float.MAX_VALUE
                    satellites.forEach { sat ->
                        val pos = satelliteCanvasPosition(sat, cx, cy, maxR)
                        val dist = hypot(unrotatedTapX - pos.x, unrotatedTapY - pos.y)
                        if (dist <= hitRadiusPx && dist < closestDist) {
                            closestDist = dist
                            closestKey = sat.key
                        }
                    }
                    onSelectSatellite(closestKey)
                }
            },
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val maxR = (minOf(size.width, size.height) / 2f) * 0.84f
        val center = Offset(cx, cy)

        // Subtle radar background disc
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    primaryColor.copy(alpha = if (fixState == FixState.FIX_3D) 0.08f else 0.04f),
                    surfaceColor.copy(alpha = 0.5f),
                ),
                center = center,
                radius = maxR,
            ),
            radius = maxR,
            center = center,
        )

        // Concentric elevation rings: 0° (horizon), 30°, 60°
        val dashedEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
        drawCircle(
            color = gridColor,
            radius = maxR,
            center = center,
            style = Stroke(width = 1.8.dp.toPx()),
        )
        drawCircle(
            color = subGridColor,
            radius = maxR * (60f / 90f),
            center = center,
            style = Stroke(width = 1.dp.toPx(), pathEffect = dashedEffect),
        )
        drawCircle(
            color = subGridColor,
            radius = maxR * (30f / 90f),
            center = center,
            style = Stroke(width = 1.dp.toPx(), pathEffect = dashedEffect),
        )

        // Animated radar sweep beam while searching
        if (isSearching) {
            drawArc(
                brush = Brush.sweepGradient(
                    0.0f to Color.Transparent,
                    0.82f to Color.Transparent,
                    1.0f to primaryColor.copy(alpha = 0.28f),
                    center = center,
                ),
                startAngle = sweepAngle - 90f,
                sweepAngle = 65f,
                useCenter = true,
                topLeft = Offset(cx - maxR, cy - maxR),
                size = androidx.compose.ui.geometry.Size(maxR * 2f, maxR * 2f),
            )
        }

        // Fixed top heading lubber marker when compass alignment is active
        if (rotationDeg != 0f) {
            val tipY = cy - maxR + 2.dp.toPx()
            val lubberPath = Path().apply {
                moveTo(cx, tipY + 7.dp.toPx())
                lineTo(cx - 5.dp.toPx(), tipY - 3.dp.toPx())
                lineTo(cx + 5.dp.toPx(), tipY - 3.dp.toPx())
                close()
            }
            drawPath(path = lubberPath, color = primaryColor)
        }

        rotate(degrees = rotationDeg, pivot = center) {
            // Diagonal 45° & cardinal crosshair lines + 15° horizon ticks
            for (deg in 0 until 360 step 15) {
                val rad = Math.toRadians(deg.toDouble() - 90.0)
                val cosA = cos(rad).toFloat()
                val sinA = sin(rad).toFloat()
                val end = Offset(x = cx + maxR * cosA, y = cy + maxR * sinA)
                if (deg % 45 == 0) {
                    val isCardinal = deg % 90 == 0
                    drawLine(
                        color = if (isCardinal) gridColor else subGridColor,
                        start = center,
                        end = end,
                        strokeWidth = if (isCardinal) 1.2.dp.toPx() else 0.8.dp.toPx(),
                    )
                } else {
                    val tickStart = Offset(
                        x = cx + (maxR - 5.dp.toPx()) * cosA,
                        y = cy + (maxR - 5.dp.toPx()) * sinA,
                    )
                    drawLine(
                        color = subGridColor,
                        start = tickStart,
                        end = end,
                        strokeWidth = 1.dp.toPx(),
                    )
                }
            }

            // Cardinal Labels (N, E, S, W)
            val cardinalStyle = TextStyle(
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = labelColor,
            )
            drawCardinalLabel(textMeasurer, "N", cx, cy - maxR - 14.dp.toPx(), cardinalStyle.copy(color = primaryColor))
            drawCardinalLabel(textMeasurer, "S", cx, cy + maxR + 14.dp.toPx(), cardinalStyle)
            drawCardinalLabel(textMeasurer, "E", cx + maxR + 14.dp.toPx(), cy, cardinalStyle)
            drawCardinalLabel(textMeasurer, "W", cx - maxR - 14.dp.toPx(), cy, cardinalStyle)

            // Elevation degree ticks
            val degStyle = TextStyle(
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 9.sp,
                color = labelColor.copy(alpha = 0.7f),
            )
            drawCardinalLabel(textMeasurer, "60°", cx + 14.dp.toPx(), cy - maxR * (30f / 90f), degStyle)
            drawCardinalLabel(textMeasurer, "30°", cx + 14.dp.toPx(), cy - maxR * (60f / 90f), degStyle)

            // Plot Satellites
            val satLabelStyle = TextStyle(
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 9.sp,
            )

            satellites.forEach { sat ->
                val pos = satelliteCanvasPosition(sat, cx, cy, maxR)
                val color = sat.constellation.color
                val isSelected = sat.key == selectedKey
                val dotRadius = if (sat.usedInFix) 6.5.dp.toPx() else 5.dp.toPx()

                if (isSelected) {
                    drawCircle(
                        color = primaryTextColor.copy(alpha = 0.25f),
                        radius = dotRadius + 7.dp.toPx(),
                        center = pos,
                    )
                }

                if (sat.usedInFix) {
                    drawCircle(
                        color = color.copy(alpha = 0.25f),
                        radius = dotRadius + 4.dp.toPx(),
                        center = pos,
                    )
                    drawCircle(
                        color = color,
                        radius = dotRadius,
                        center = pos,
                    )
                    drawCircle(
                        color = primaryTextColor.copy(alpha = 0.85f),
                        radius = dotRadius,
                        center = pos,
                        style = Stroke(width = 1.4.dp.toPx()),
                    )
                } else {
                    drawCircle(
                        color = surfaceColor,
                        radius = dotRadius,
                        center = pos,
                    )
                    drawCircle(
                        color = color.copy(alpha = 0.8f),
                        radius = dotRadius,
                        center = pos,
                        style = Stroke(width = 2.dp.toPx()),
                    )
                }

                val labelResult = textMeasurer.measure(
                    text = sat.key,
                    style = satLabelStyle.copy(color = if (sat.usedInFix) primaryTextColor else color),
                )
                val labelX = (pos.x - labelResult.size.width / 2f)
                    .coerceIn(4f, size.width - labelResult.size.width - 4f)
                val labelY = (pos.y + dotRadius + 2.dp.toPx())
                    .coerceIn(4f, size.height - labelResult.size.height - 4f)
                drawText(
                    textLayoutResult = labelResult,
                    topLeft = Offset(labelX, labelY),
                )
            }
        }
    }
}

fun satelliteCanvasPosition(
    sat: SatelliteInfo,
    cx: Float,
    cy: Float,
    maxR: Float,
): Offset {
    val normalizedEl = (90f - sat.elevationDeg.coerceIn(0f, 90f)) / 90f
    val r = maxR * normalizedEl
    val azRad = Math.toRadians((sat.azimuthDeg - 90f).toDouble())
    return Offset(
        x = cx + (r * cos(azRad)).toFloat(),
        y = cy + (r * sin(azRad)).toFloat(),
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCardinalLabel(
    textMeasurer: TextMeasurer,
    text: String,
    centerX: Float,
    centerY: Float,
    style: TextStyle,
) {
    val result = textMeasurer.measure(text = text, style = style)
    drawText(
        textLayoutResult = result,
        topLeft = Offset(
            x = centerX - result.size.width / 2f,
            y = centerY - result.size.height / 2f,
        ),
    )
}

@Composable
private fun SelectedSatelliteCard(
    satellite: SatelliteInfo,
    onDismiss: () -> Unit,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = satellite.constellation.color.copy(alpha = 0.6f),
                shape = MaterialTheme.shapes.medium,
            ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f),
            ) {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(satellite.constellation.color),
                )
                Column {
                    Text(
                        text = "${satellite.constellation.displayName} ${satellite.key}" +
                            if (satellite.bandLabel != null) " · ${satellite.bandLabel}" else "",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = String.format(
                            Locale.US,
                            "CN0 %.1f dB-Hz · Az %.0f° · El %.0f° · %s",
                            satellite.cn0DbHz,
                            satellite.azimuthDeg,
                            satellite.elevationDeg,
                            if (satellite.usedInFix) "USED IN FIX" else "TRACKING",
                        ),
                        style = TabularMonoStyle.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            IconButton(onClick = onDismiss) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Close satellite detail",
                )
            }
        }
    }
}

@Composable
private fun ConstellationPill(
    constellation: Constellation,
    usedCount: Int,
    totalCount: Int,
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(constellation.color),
            )
            Text(
                text = constellation.displayName,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(modifier = Modifier.width(2.dp))
            Text(
                text = "$usedCount/$totalCount",
                style = TabularMonoStyle.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                color = if (usedCount > 0) constellation.color else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
