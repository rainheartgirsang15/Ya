package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Constellation
import com.example.model.GnssTelemetryState
import com.example.model.SatelliteInfo
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.AmberSearch
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.TabularMonoStyle
import com.example.viewmodel.SatelliteFilter
import java.util.Locale

@Composable
fun SignalsScreen(
    telemetry: GnssTelemetryState,
    activeFilter: SatelliteFilter,
    onSelectFilter: (SatelliteFilter) -> Unit,
    matchesFilter: (Constellation, Boolean, SatelliteFilter) -> Boolean,
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier,
) {
    val filteredSatellites = telemetry.satellites.filter {
        matchesFilter(it.constellation, it.usedInFix, activeFilter)
    }

    val maxCn0 = telemetry.satellites.maxOfOrNull { it.cn0DbHz }
    val avgCn0 = telemetry.avgUsedCn0

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(contentPadding),
        contentAlignment = Alignment.TopCenter,
    ) {
        SatelliteSignalBarList(
            satellites = filteredSatellites,
            usedCount = telemetry.usedSatelliteCount,
            visibleCount = telemetry.visibleSatelliteCount,
            supportsDualFrequency = telemetry.supportsDualFrequency,
            avgCn0 = avgCn0,
            maxCn0 = maxCn0,
            activeFilter = activeFilter,
            onSelectFilter = onSelectFilter,
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
        )
    }
}

@Composable
fun SatelliteSignalBarList(
    satellites: List<SatelliteInfo>,
    usedCount: Int,
    visibleCount: Int,
    supportsDualFrequency: Boolean,
    avgCn0: Float?,
    maxCn0: Float?,
    activeFilter: SatelliteFilter,
    onSelectFilter: (SatelliteFilter) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier.testTag("satellite_signal_bar_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item(key = "header_section") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.signals_title),
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        Text(
                            text = "$usedCount used · $visibleCount visible",
                            style = TabularMonoStyle.copy(fontSize = 12.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (supportsDualFrequency) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                        ) {
                            Text(
                                text = "L1 + L5",
                                style = TabularMonoStyle.copy(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                ),
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            )
                        }
                    }
                }

                // Signal Summary Strip
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    SignalStatTile(
                        label = "AVG USED CN0",
                        value = avgCn0?.let { String.format(Locale.US, "%.1f dB-Hz", it) } ?: "—",
                        modifier = Modifier.weight(1f),
                    )
                    SignalStatTile(
                        label = "PEAK CN0",
                        value = maxCn0?.let { String.format(Locale.US, "%.1f dB-Hz", it) } ?: "—",
                        modifier = Modifier.weight(1f),
                    )
                }

                // Filter Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    val filters = listOf(
                        SatelliteFilter.ALL to stringResource(R.string.filter_all),
                        SatelliteFilter.USED to stringResource(R.string.filter_used),
                        SatelliteFilter.GPS to "GPS",
                        SatelliteFilter.GLONASS to "GLO",
                        SatelliteFilter.GALILEO to "GAL",
                        SatelliteFilter.BEIDOU to "BDS",
                        SatelliteFilter.QZSS to "QZSS",
                        SatelliteFilter.SBAS to "SBAS",
                    )
                    filters.forEach { (filter, label) ->
                        FilterChip(
                            selected = activeFilter == filter,
                            onClick = { onSelectFilter(filter) },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            ),
                            modifier = Modifier.testTag("sat_filter_${filter.name.lowercase()}"),
                        )
                    }
                }

                // Vertical CN0 Bar Spectrum Strip
                if (satellites.isNotEmpty()) {
                    Cn0VerticalBarSpectrum(satellites = satellites)
                }
            }
        }

        if (satellites.isEmpty()) {
            item(key = "empty_state") {
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SignalCellularAlt,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                        )
                        Text(
                            text = stringResource(R.string.signals_empty),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        } else {
            itemsIndexed(
                items = satellites,
                key = { index, sat -> "${sat.key}_${sat.carrierFreqMhz ?: 0f}_$index" },
            ) { _, sat ->
                SatelliteSignalBarRow(satellite = sat)
            }
        }
    }
}

@Composable
private fun Cn0VerticalBarSpectrum(
    satellites: List<SatelliteInfo>,
) {
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    val trackColor = MaterialTheme.colorScheme.surfaceContainerHighest

    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
                shape = MaterialTheme.shapes.large,
            )
            .testTag("cn0_vertical_spectrum"),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "LIVE CN0 BAR SPECTRUM (dB-Hz)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = "0 – 50 dB-Hz",
                    style = TabularMonoStyle.copy(fontSize = 10.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(148.dp),
            ) {
                // Background threshold guide lines (15, 30, 45 dB-Hz)
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 18.dp, bottom = 24.dp),
                ) {
                    val dash = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                    listOf(15f, 30f, 45f).forEach { threshold ->
                        val y = size.height * (1f - (threshold / 50f))
                        drawLine(
                            color = gridColor,
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = dash,
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.Bottom,
                ) {
                    satellites.forEach { sat ->
                        val fraction by animateFloatAsState(
                            targetValue = (sat.cn0DbHz / 50f).coerceIn(0.03f, 1f),
                            animationSpec = tween(durationMillis = 250),
                            label = "spectrum_bar_${sat.key}",
                        )
                        val barColor = cn0ColorFor(sat.cn0DbHz)

                        Column(
                            modifier = Modifier
                                .width(32.dp)
                                .fillMaxHeight()
                                .semantics {
                                    contentDescription =
                                        "${sat.constellation.displayName} ${sat.svid} ${String.format(Locale.US, "%.1f", sat.cn0DbHz)} dB-Hz"
                                },
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom,
                        ) {
                            Text(
                                text = String.format(Locale.US, "%.0f", sat.cn0DbHz),
                                style = TabularMonoStyle.copy(
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                ),
                                color = barColor,
                                maxLines = 1,
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Box(
                                modifier = Modifier
                                    .width(16.dp)
                                    .weight(1f)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(trackColor.copy(alpha = 0.55f)),
                                contentAlignment = Alignment.BottomCenter,
                            ) {
                                Canvas(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .fillMaxHeight(fraction),
                                ) {
                                    drawRoundRect(
                                        color = if (sat.usedInFix) barColor else barColor.copy(alpha = 0.45f),
                                        topLeft = Offset.Zero,
                                        size = Size(size.width, size.height),
                                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = sat.key,
                                style = TabularMonoStyle.copy(
                                    fontSize = 10.sp,
                                    fontWeight = if (sat.usedInFix) FontWeight.Bold else FontWeight.Normal,
                                ),
                                color = if (sat.usedInFix) sat.constellation.color else MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Clip,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SignalStatTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier.border(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant,
            shape = MaterialTheme.shapes.medium,
        ),
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = TabularMonoStyle.copy(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                ),
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

@Composable
fun SatelliteSignalBarRow(
    satellite: SatelliteInfo,
    modifier: Modifier = Modifier,
) {
    val signalFraction by animateFloatAsState(
        targetValue = (satellite.cn0DbHz / 50f).coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 250),
        label = "cn0_bar",
    )

    val barColor = cn0ColorFor(satellite.cn0DbHz)

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(
            containerColor = if (satellite.usedInFix) {
                MaterialTheme.colorScheme.surface
            } else {
                MaterialTheme.colorScheme.surfaceContainerLow
            },
        ),
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (satellite.usedInFix) {
                    satellite.constellation.color.copy(alpha = 0.45f)
                } else {
                    MaterialTheme.colorScheme.outlineVariant
                },
                shape = MaterialTheme.shapes.medium,
            )
            .testTag("sat_signal_row_${satellite.key}"),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(satellite.constellation.color),
                    )
                    Text(
                        text = satellite.key,
                        style = TabularMonoStyle.copy(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                        ),
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = satellite.constellation.displayName,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    satellite.bandLabel?.let { band ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                        ) {
                            Text(
                                text = band,
                                style = TabularMonoStyle.copy(fontSize = 10.sp, fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            )
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    FlagBadge(label = "U", active = satellite.usedInFix, activeColor = SignalEmerald)
                    FlagBadge(label = "E", active = satellite.hasEphemeris, activeColor = MaterialTheme.colorScheme.secondary)
                    FlagBadge(label = "A", active = satellite.hasAlmanac, activeColor = MaterialTheme.colorScheme.tertiary)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = String.format(Locale.US, "%.1f", satellite.cn0DbHz),
                        style = TabularMonoStyle.copy(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                        ),
                        color = barColor,
                    )
                    Text(
                        text = "dB-Hz",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // CN0 Horizontal Bar with 15 / 30 / 45 dB-Hz tick marks
            val tickColor = MaterialTheme.colorScheme.background.copy(alpha = 0.45f)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHighest),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(signalFraction)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(5.dp))
                        .background(if (satellite.usedInFix) barColor else barColor.copy(alpha = 0.65f)),
                )
                Canvas(modifier = Modifier.fillMaxSize()) {
                    listOf(0.3f, 0.6f, 0.9f).forEach { mark ->
                        val x = size.width * mark
                        drawLine(
                            color = tickColor,
                            start = Offset(x, 0f),
                            end = Offset(x, size.height),
                            strokeWidth = 1.dp.toPx(),
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = String.format(
                        Locale.US,
                        "AZ %03.0f° · EL %02.0f°",
                        satellite.azimuthDeg,
                        satellite.elevationDeg,
                    ),
                    style = TabularMonoStyle.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = if (satellite.usedInFix) "LOCKED IN FIX" else "STANDBY",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (satellite.usedInFix) SignalEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

private fun cn0ColorFor(cn0DbHz: Float): Color = when {
    cn0DbHz >= 28f -> SignalEmerald
    cn0DbHz >= 16f -> AmberSearch
    else -> AlertCrimson
}

@Composable
private fun FlagBadge(
    label: String,
    active: Boolean,
    activeColor: Color,
) {
    Surface(
        shape = RoundedCornerShape(5.dp),
        color = if (active) activeColor.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceContainerHighest,
    ) {
        Text(
            text = label,
            style = TabularMonoStyle.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
            color = if (active) activeColor else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
        )
    }
}
