package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AppSettings
import com.example.model.CoordFormat
import com.example.model.DistanceUnit
import com.example.model.SpeedUnit
import com.example.model.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    settings: AppSettings,
    onDismiss: () -> Unit,
    onSelectCoordFormat: (CoordFormat) -> Unit,
    onSelectSpeedUnit: (SpeedUnit) -> Unit,
    onSelectDistanceUnit: (DistanceUnit) -> Unit,
    onToggleKeepScreenOn: () -> Unit,
    onToggleLockNotification: () -> Unit,
    onSelectThemeMode: (ThemeMode) -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = stringResource(R.string.settings_title),
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurface,
            )

            // Coordinate Format
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stringResource(R.string.settings_coord_format),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CoordFormat.entries.forEach { format ->
                        FilterChip(
                            selected = settings.coordFormat == format,
                            onClick = { onSelectCoordFormat(format) },
                            label = { Text(format.label) },
                            modifier = Modifier.testTag("setting_coord_${format.name.lowercase()}"),
                        )
                    }
                }
            }

            // Speed Unit
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stringResource(R.string.settings_speed_unit),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SpeedUnit.entries.forEach { unit ->
                        FilterChip(
                            selected = settings.speedUnit == unit,
                            onClick = { onSelectSpeedUnit(unit) },
                            label = { Text(unit.label) },
                            modifier = Modifier.testTag("setting_speed_${unit.name.lowercase()}"),
                        )
                    }
                }
            }

            // Distance / Altitude Unit
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stringResource(R.string.settings_distance_unit),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DistanceUnit.entries.forEach { unit ->
                        FilterChip(
                            selected = settings.distanceUnit == unit,
                            onClick = { onSelectDistanceUnit(unit) },
                            label = { Text(if (unit == DistanceUnit.METRIC) "Meters (m)" else "Feet (ft)") },
                            modifier = Modifier.testTag("setting_distance_${unit.name.lowercase()}"),
                        )
                    }
                }
            }

            // Theme Mode
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stringResource(R.string.settings_theme),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = settings.themeMode == ThemeMode.DARK,
                        onClick = { onSelectThemeMode(ThemeMode.DARK) },
                        label = { Text(stringResource(R.string.theme_dark)) },
                        modifier = Modifier.testTag("setting_theme_dark"),
                    )
                    FilterChip(
                        selected = settings.themeMode == ThemeMode.LIGHT,
                        onClick = { onSelectThemeMode(ThemeMode.LIGHT) },
                        label = { Text(stringResource(R.string.theme_light)) },
                        modifier = Modifier.testTag("setting_theme_light"),
                    )
                    FilterChip(
                        selected = settings.themeMode == ThemeMode.SYSTEM,
                        onClick = { onSelectThemeMode(ThemeMode.SYSTEM) },
                        label = { Text(stringResource(R.string.theme_system)) },
                        modifier = Modifier.testTag("setting_theme_system"),
                    )
                }
            }

            // GPS Lock Alert Notification
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                    Text(
                        text = stringResource(R.string.lock_notif_toggle_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = stringResource(R.string.lock_notif_toggle_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = settings.lockNotificationEnabled,
                    onCheckedChange = { onToggleLockNotification() },
                    modifier = Modifier.testTag("setting_lock_notification"),
                )
            }

            // Keep Screen Awake
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.keep_screen_on),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Switch(
                    checked = settings.keepScreenOn,
                    onCheckedChange = { onToggleKeepScreenOn() },
                    modifier = Modifier.testTag("setting_keep_screen_on"),
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
