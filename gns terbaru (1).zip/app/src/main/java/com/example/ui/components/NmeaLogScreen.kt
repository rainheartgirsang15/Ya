package com.example.ui.components

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.GnssTelemetryState
import com.example.model.NmeaEntry
import com.example.model.NmeaType
import com.example.ui.theme.AmberSearch
import com.example.ui.theme.ConstellationGalileoColor
import com.example.ui.theme.ConstellationGpsColor
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.TabularMonoStyle
import com.example.util.Formatters

@Composable
fun NmeaLogScreen(
    telemetry: GnssTelemetryState,
    selectedFilter: NmeaType?,
    onSelectFilter: (NmeaType?) -> Unit,
    onTogglePause: () -> Unit,
    onClearLogs: () -> Unit,
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    val filtered = if (selectedFilter == null) {
        telemetry.nmeaLogs
    } else {
        telemetry.nmeaLogs.filter { it.type == selectedFilter }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(contentPadding),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.nmea_title),
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        val isLive = telemetry.isGnssEngineRunning && !telemetry.nmeaPaused
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(if (isLive) SignalEmerald else AmberSearch),
                        )
                        Text(
                            text = "${if (telemetry.nmeaPaused) "PAUSED" else "LIVE"} · ${filtered.size} sentences",
                            style = TabularMonoStyle.copy(fontSize = 12.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalIconButton(
                        onClick = onTogglePause,
                        modifier = Modifier.testTag("nmea_pause_button"),
                    ) {
                        Icon(
                            imageVector = if (telemetry.nmeaPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                            contentDescription = if (telemetry.nmeaPaused) {
                                stringResource(R.string.nmea_resume)
                            } else {
                                stringResource(R.string.nmea_pause)
                            },
                        )
                    }
                    FilledTonalIconButton(
                        onClick = {
                            if (filtered.isNotEmpty()) {
                                val text = filtered.joinToString("\n") { it.sentence }
                                clipboard.setText(AnnotatedString(text))
                                Toast.makeText(context, "NMEA copied", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.testTag("nmea_copy_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ContentCopy,
                            contentDescription = stringResource(R.string.nmea_copy),
                        )
                    }
                    FilledTonalIconButton(
                        onClick = {
                            if (filtered.isNotEmpty()) {
                                val text = filtered.joinToString("\n") { it.sentence }
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, text)
                                }
                                runCatching { context.startActivity(Intent.createChooser(sendIntent, null)) }
                            }
                        },
                        modifier = Modifier.testTag("nmea_share_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Share,
                            contentDescription = stringResource(R.string.btn_share_coords),
                        )
                    }
                    FilledTonalIconButton(
                        onClick = onClearLogs,
                        modifier = Modifier.testTag("nmea_clear_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteSweep,
                            contentDescription = stringResource(R.string.nmea_clear),
                        )
                    }
                }
            }

            // NMEA Type Filter Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                val options: List<Pair<NmeaType?, String>> = listOf(
                    null to stringResource(R.string.filter_all),
                    NmeaType.GGA to "GGA",
                    NmeaType.GSA to "GSA",
                    NmeaType.RMC to "RMC",
                    NmeaType.GSV to "GSV",
                    NmeaType.OTHER to "OTHER",
                )
                options.forEach { (type, label) ->
                    FilterChip(
                        selected = selectedFilter == type,
                        onClick = { onSelectFilter(type) },
                        label = { Text(label) },
                        modifier = Modifier.testTag("nmea_filter_${label.lowercase()}"),
                    )
                }
            }

            // Terminal Surface
            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .fillMaxSize()
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant,
                        shape = MaterialTheme.shapes.large,
                    )
                    .testTag("nmea_stream_container"),
            ) {
                if (filtered.isEmpty()) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Terminal,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                        )
                        Text(
                            text = stringResource(R.string.nmea_empty),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    SelectionContainer {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            items(filtered, key = { it.id }) { entry ->
                                NmeaSentenceRow(entry = entry)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NmeaSentenceRow(entry: NmeaEntry) {
    val badgeColor = when (entry.type) {
        NmeaType.GGA -> SignalEmerald
        NmeaType.GSA -> AmberSearch
        NmeaType.RMC -> ConstellationGpsColor
        NmeaType.GSV -> ConstellationGalileoColor
        NmeaType.OTHER -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    val talker = entry.sentence.removePrefix("$").take(2).takeIf { it.length == 2 } ?: "--"

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = entry.type.name,
                        style = TabularMonoStyle.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                        color = badgeColor,
                    )
                    Text(
                        text = talker,
                        style = TabularMonoStyle.copy(fontSize = 10.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(
                    text = Formatters.formatTimestamp(entry.timestampMillis),
                    style = TabularMonoStyle.copy(fontSize = 10.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(
                text = entry.sentence,
                style = TabularMonoStyle.copy(fontSize = 11.5.sp, lineHeight = 15.sp),
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}
