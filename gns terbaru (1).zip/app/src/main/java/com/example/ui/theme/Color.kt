package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Obsidian Cockpit Palette
val ObsidianBg = Color(0xFF090E14)
val ObsidianSurface = Color(0xFF101720)
val ObsidianSurfaceHigh = Color(0xFF17212E)
val ObsidianSurfaceHighest = Color(0xFF1F2C3D)
val ObsidianOutline = Color(0xFF2B3B4E)

// Daylight Instrument Palette
val DaylightBg = Color(0xFFF3F6FA)
val DaylightSurface = Color(0xFFFFFFFF)
val DaylightSurfaceHigh = Color(0xFFE9EFF6)
val DaylightSurfaceHighest = Color(0xFFDCE5F0)
val DaylightOutline = Color(0xFFBFD0E2)

// Semantic Telemetry Accents
val SignalEmerald = Color(0xFF10E88A)
val SignalEmeraldDark = Color(0xFF008A50)
val SignalEmeraldContainerDark = Color(0xFF073321)
val SignalEmeraldContainerLight = Color(0xFFD0FBE6)

val TelemetryCyan = Color(0xFF38BDF8)
val TelemetryCyanDark = Color(0xFF0277BD)
val TelemetryCyanContainerDark = Color(0xFF0B2F47)
val TelemetryCyanContainerLight = Color(0xFFD7F0FE)

val AmberSearch = Color(0xFFFFB020)
val AmberSearchDark = Color(0xFFB86E00)
val AmberContainerDark = Color(0xFF3A2704)
val AmberContainerLight = Color(0xFFFFEFC7)

val AlertCrimson = Color(0xFFFF4D5E)
val AlertCrimsonDark = Color(0xFFC62839)
val AlertContainerDark = Color(0xFF3D0E15)
val AlertContainerLight = Color(0xFFFFDAD9)

// Constellation Accent Colors
val ConstellationGpsColor = Color(0xFF38BDF8)
val ConstellationGlonassColor = Color(0xFFFB7185)
val ConstellationGalileoColor = Color(0xFFA78BFA)
val ConstellationBeidouColor = Color(0xFFFBBF24)
val ConstellationQzssColor = Color(0xFF34D399)
val ConstellationIrnssColor = Color(0xFFF472B6)
val ConstellationSbasColor = Color(0xFF94A3B8)
