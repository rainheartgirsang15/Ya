package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.ThemeMode

private val CockpitDarkColorScheme = darkColorScheme(
    primary = SignalEmerald,
    onPrimary = Color(0xFF002414),
    primaryContainer = SignalEmeraldContainerDark,
    onPrimaryContainer = SignalEmerald,
    secondary = TelemetryCyan,
    onSecondary = Color(0xFF002233),
    secondaryContainer = TelemetryCyanContainerDark,
    onSecondaryContainer = TelemetryCyan,
    tertiary = AmberSearch,
    onTertiary = Color(0xFF2B1900),
    tertiaryContainer = AmberContainerDark,
    onTertiaryContainer = AmberSearch,
    error = AlertCrimson,
    onError = Color(0xFF330007),
    errorContainer = AlertContainerDark,
    onErrorContainer = AlertCrimson,
    background = ObsidianBg,
    onBackground = Color(0xFFE7EFF7),
    surface = ObsidianSurface,
    onSurface = Color(0xFFE7EFF7),
    surfaceVariant = ObsidianSurfaceHigh,
    onSurfaceVariant = Color(0xFF93A5B8),
    surfaceContainerLowest = ObsidianBg,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = ObsidianSurfaceHigh,
    surfaceContainerHigh = ObsidianSurfaceHighest,
    surfaceContainerHighest = Color(0xFF263549),
    outline = ObsidianOutline,
    outlineVariant = Color(0xFF1D2938),
)

private val DaylightLightColorScheme = lightColorScheme(
    primary = SignalEmeraldDark,
    onPrimary = Color.White,
    primaryContainer = SignalEmeraldContainerLight,
    onPrimaryContainer = Color(0xFF002916),
    secondary = TelemetryCyanDark,
    onSecondary = Color.White,
    secondaryContainer = TelemetryCyanContainerLight,
    onSecondaryContainer = Color(0xFF00253A),
    tertiary = AmberSearchDark,
    onTertiary = Color.White,
    tertiaryContainer = AmberContainerLight,
    onTertiaryContainer = Color(0xFF361F00),
    error = AlertCrimsonDark,
    onError = Color.White,
    errorContainer = AlertContainerLight,
    onErrorContainer = Color(0xFF410008),
    background = DaylightBg,
    onBackground = Color(0xFF0E1722),
    surface = DaylightSurface,
    onSurface = Color(0xFF0E1722),
    surfaceVariant = DaylightSurfaceHigh,
    onSurfaceVariant = Color(0xFF4B5E73),
    surfaceContainerLowest = DaylightSurface,
    surfaceContainerLow = DaylightBg,
    surfaceContainer = DaylightSurfaceHigh,
    surfaceContainerHigh = DaylightSurfaceHighest,
    surfaceContainerHighest = Color(0xFFD0DCEB),
    outline = DaylightOutline,
    outlineVariant = Color(0xFFD6E1EE),
)

val GnssShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun GnssFixTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    content: @Composable () -> Unit,
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }

    val colorScheme = if (darkTheme) CockpitDarkColorScheme else DaylightLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = GnssTypography,
        shapes = GnssShapes,
        content = content,
    )
}
