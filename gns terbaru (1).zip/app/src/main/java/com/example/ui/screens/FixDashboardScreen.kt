package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CompassCalibration
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.GpsFixed
import androidx.compose.material.icons.rounded.GpsNotFixed
import androidx.compose.material.icons.rounded.GpsOff
import androidx.compose.material.icons.rounded.Height
import androidx.compose.material.icons.rounded.LocationSearching
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.DriverPresetMatch
import com.example.data.PriorityAppHelper
import com.example.model.AppSettings
import com.example.model.CompassAccuracy
import com.example.model.CompassState
import com.example.model.FixState
import com.example.model.GnssSignalGrade
import com.example.model.GnssTelemetryState
import com.example.model.PriorityAppInfo
import com.example.model.SpeedUnit
import com.example.ui.components.CompassCalibrationDialog
import com.example.ui.components.SpeedometerCard
import com.example.ui.components.compassAccuracyColor
import com.example.ui.components.compassAccuracyText
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.AmberSearch
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.TabularMonoStyle
import com.example.ui.theme.TelemetryCyan
import com.example.util.Formatters
import java.util.Locale

@Composable
fun FixDashboardScreen(
    telemetry: GnssTelemetryState,
    settings: AppSettings,
    nowMillis: Long,
    permissionPermanentlyDenied: Boolean,
    onRequestLocationPermission: () -> Unit,
    onOpenAppSettings: () -> Unit,
    onToggleBackgroundLock: () -> Unit,
    onBoostAgps: () -> Unit,
    onColdReset: () -> Unit,
    onDismissAgpsFeedback: () -> Unit,
    onCycleCoordFormat: () -> Unit,
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier,
    compass: CompassState = CompassState(),
    onOpenCompass: () -> Unit = {},
    onResampleCompass: () -> Unit = {},
    onSelectSpeedUnit: (SpeedUnit) -> Unit = {},
    onResetMaxSpeed: () -> Unit = {},
    hasNotificationPermission: Boolean = true,
    onToggleLockNotification: () -> Unit = {},
    onRequestNotificationPermission: () -> Unit = {},
    installedPriorityApps: List<PriorityAppInfo> = emptyList(),
    onSelectPriorityApp: (String?) -> Unit = {},
    onEnsureBackgroundLock: () -> Unit = {},
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var showColdResetDialog by remember { mutableStateOf(false) }
    var showCompassCalibrateDialog by remember { mutableStateOf(false) }
    var showPriorityAppPicker by remember { mutableStateOf(false) }
    var showGojekGuideDialog by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(contentPadding)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 840.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Permission or GPS Off Banner
            if (!telemetry.hasLocationPermission) {
                val permDescription = when {
                    permissionPermanentlyDenied -> stringResource(R.string.status_desc_permission_denied)
                    telemetry.hasCoarseLocationPermission -> stringResource(R.string.status_desc_coarse_only)
                    else -> stringResource(R.string.status_desc_no_permission)
                }
                val permButtonLabel = when {
                    permissionPermanentlyDenied -> stringResource(R.string.btn_open_app_settings)
                    telemetry.hasCoarseLocationPermission -> stringResource(R.string.btn_upgrade_precise)
                    else -> stringResource(R.string.btn_grant_permission)
                }
                ActionGateCard(
                    icon = Icons.Rounded.GpsOff,
                    title = stringResource(R.string.status_no_permission),
                    description = permDescription,
                    buttonLabel = permButtonLabel,
                    accentColor = AlertCrimson,
                    onClick = if (permissionPermanentlyDenied) onOpenAppSettings else onRequestLocationPermission,
                    buttonTestTag = "grant_permission_button",
                )
            } else if (!telemetry.isGpsProviderEnabled) {
                ActionGateCard(
                    icon = Icons.Rounded.GpsOff,
                    title = stringResource(R.string.status_gps_disabled),
                    description = stringResource(R.string.status_desc_gps_disabled),
                    buttonLabel = stringResource(R.string.btn_open_location_settings),
                    accentColor = AmberSearch,
                    onClick = {
                        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                        runCatching { context.startActivity(intent) }
                    },
                    buttonTestTag = "open_location_settings_button",
                )
            }

            // Hero GNSS Fix Lock Status Card
            HeroFixStatusCard(
                telemetry = telemetry,
                settings = settings,
                nowMillis = nowMillis,
            )

            // A-GPS Boost & Cold Reset Action Row
            if (telemetry.hasLocationPermission && telemetry.isGpsProviderEnabled) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Button(
                        onClick = onBoostAgps,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(50.dp)
                            .testTag("boost_agps_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Bolt,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.btn_boost_agps),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }

                    OutlinedButton(
                        onClick = { showColdResetDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("cold_reset_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.RestartAlt,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.btn_cold_reset),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                BackgroundLockCard(
                    isEnabled = settings.backgroundLockEnabled,
                    isServiceActive = telemetry.isBackgroundServiceActive,
                    onToggle = onToggleBackgroundLock,
                )

                LockNotificationCard(
                    isEnabled = settings.lockNotificationEnabled,
                    hasNotificationPermission = hasNotificationPermission,
                    onToggle = onToggleLockNotification,
                    onRequestPermission = onRequestNotificationPermission,
                )

                PriorityBindingCard(
                    isBatteryUnrestricted = telemetry.isBatteryOptimizationIgnored,
                    selectedPackage = settings.priorityAppPackage,
                    installedApps = installedPriorityApps,
                    onOpenBatterySettings = { PriorityAppHelper.openBatteryOptimizationSettings(context) },
                    onChooseApp = { showPriorityAppPicker = true },
                    onBindAndLaunch = {
                        onEnsureBackgroundLock()
                        val fix = telemetry.locationFix
                        val intent = PriorityAppHelper.buildLaunchIntent(
                            context = context,
                            packageName = settings.priorityAppPackage,
                            lat = fix?.latitude,
                            lon = fix?.longitude,
                        )
                        runCatching { context.startActivity(intent) }
                    },
                    onQuickBindDriver = { pkg ->
                        onSelectPriorityApp(pkg)
                        onEnsureBackgroundLock()
                        val fix = telemetry.locationFix
                        val intent = PriorityAppHelper.buildLaunchIntent(
                            context = context,
                            packageName = pkg,
                            lat = fix?.latitude,
                            lon = fix?.longitude,
                        )
                        runCatching { context.startActivity(intent) }
                    },
                    onDriverNotInstalled = { driverName ->
                        Toast.makeText(
                            context,
                            context.getString(R.string.priority_driver_not_installed_toast, driverName),
                            Toast.LENGTH_SHORT,
                        ).show()
                        showGojekGuideDialog = true
                    },
                    onShowDriverGuide = { showGojekGuideDialog = true },
                )
            }

            // A-GPS Feedback Banner
            AnimatedVisibility(visible = telemetry.agpsFeedback != null) {
                telemetry.agpsFeedback?.let { feedback ->
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                text = feedback.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.weight(1f),
                            )
                            IconButton(
                                onClick = onDismissAgpsFeedback,
                                modifier = Modifier.minimumInteractiveComponentSize(),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Dismiss",
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                )
                            }
                        }
                    }
                }
            }

            // Circular Ground Speedometer Gauge
            SpeedometerCard(
                speedMps = telemetry.locationFix?.speedMps,
                speedAccuracyMps = telemetry.locationFix?.speedAccuracyMps,
                maxSpeedMps = telemetry.maxSpeedMps,
                hasFix = telemetry.locationFix != null,
                selectedUnit = settings.speedUnit,
                onSelectUnit = onSelectSpeedUnit,
                onResetPeak = onResetMaxSpeed,
            )

            // Coordinates Card
            CoordinatesCard(
                telemetry = telemetry,
                settings = settings,
                onCycleFormat = onCycleCoordFormat,
                onCopy = {
                    val fix = telemetry.locationFix ?: return@CoordinatesCard
                    val coordsText = String.format(
                        Locale.US,
                        "%.6f, %.6f",
                        fix.latitude,
                        fix.longitude,
                    )
                    clipboard.setText(AnnotatedString(coordsText))
                    Toast.makeText(context, "Copied: $coordsText", Toast.LENGTH_SHORT).show()
                },
                onShare = {
                    val fix = telemetry.locationFix ?: return@CoordinatesCard
                    val shareBody = String.format(
                        Locale.US,
                        "GNSS Fix: %.6f, %.6f (Acc ±%.1fm)\nhttps://maps.google.com/?q=%.6f,%.6f",
                        fix.latitude,
                        fix.longitude,
                        fix.accuracyMeters ?: 0f,
                        fix.latitude,
                        fix.longitude,
                    )
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, shareBody)
                    }
                    runCatching {
                        context.startActivity(Intent.createChooser(sendIntent, null))
                    }
                },
                onOpenMap = {
                    val fix = telemetry.locationFix ?: return@CoordinatesCard
                    val uri = Uri.parse(
                        String.format(
                            Locale.US,
                            "geo:%.6f,%.6f?q=%.6f,%.6f(GNSS+Fix)",
                            fix.latitude,
                            fix.longitude,
                            fix.latitude,
                            fix.longitude,
                        )
                    )
                    val mapIntent = Intent(Intent.ACTION_VIEW, uri)
                    runCatching { context.startActivity(mapIntent) }
                },
            )

            // Compass Quick Status Strip (only shown when hardware magnetometer is present)
            if (compass.isSupported) {
                CompassQuickCard(
                    compass = compass,
                    onOpenCompass = onOpenCompass,
                    onOpenCalibration = { showCompassCalibrateDialog = true },
                )
            }

            // Precision Telemetry Grid
            TelemetryGrid(
                telemetry = telemetry,
                settings = settings,
            )
        }
    }

    if (showColdResetDialog) {
        AlertDialog(
            onDismissRequest = { showColdResetDialog = false },
            title = { Text(stringResource(R.string.dialog_reset_title)) },
            text = { Text(stringResource(R.string.dialog_reset_body)) },
            confirmButton = {
                Button(
                    onClick = {
                        showColdResetDialog = false
                        onColdReset()
                    },
                    modifier = Modifier.testTag("confirm_cold_reset_button"),
                ) {
                    Text(stringResource(R.string.btn_confirm_reset))
                }
            },
            dismissButton = {
                TextButton(onClick = { showColdResetDialog = false }) {
                    Text(stringResource(R.string.btn_cancel))
                }
            },
        )
    }

    if (showCompassCalibrateDialog && compass.isSupported) {
        CompassCalibrationDialog(
            compass = compass,
            onResample = onResampleCompass,
            onDismiss = { showCompassCalibrateDialog = false },
        )
    }

    if (showPriorityAppPicker) {
        PriorityAppPickerDialog(
            selectedPackage = settings.priorityAppPackage,
            installedApps = installedPriorityApps,
            onSelect = { pkg ->
                onSelectPriorityApp(pkg)
                showPriorityAppPicker = false
            },
            onDismiss = { showPriorityAppPicker = false },
        )
    }

    if (showGojekGuideDialog) {
        val driverMatches = remember(installedPriorityApps) {
            PriorityAppHelper.matchDriverPlatforms(installedPriorityApps)
        }
        AlertDialog(
            onDismissRequest = { showGojekGuideDialog = false },
            title = { Text(stringResource(R.string.priority_gojek_guide_title)) },
            text = {
                Column(
                    modifier = Modifier
                        .heightIn(max = 420.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        text = stringResource(R.string.priority_gojek_guide_body),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        driverMatches.forEach { match ->
                            val installed = match.installedApp
                            val statusColor = if (installed != null) SignalEmerald else AmberSearch
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Icon(
                                    imageVector = if (installed != null) {
                                        Icons.Rounded.CheckCircle
                                    } else {
                                        Icons.Rounded.WarningAmber
                                    },
                                    contentDescription = null,
                                    tint = statusColor,
                                    modifier = Modifier.size(16.dp),
                                )
                                Text(
                                    text = match.platform.displayName,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f),
                                )
                                Text(
                                    text = if (installed != null) {
                                        stringResource(R.string.priority_driver_status_installed, installed.label)
                                    } else {
                                        stringResource(R.string.priority_driver_status_missing)
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = statusColor,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (!telemetry.isBatteryOptimizationIgnored) {
                    Button(
                        onClick = {
                            showGojekGuideDialog = false
                            PriorityAppHelper.openBatteryOptimizationSettings(context)
                        },
                        modifier = Modifier.testTag("gojek_guide_battery_button"),
                    ) {
                        Text(stringResource(R.string.priority_battery_fix_btn))
                    }
                } else {
                    TextButton(onClick = { showGojekGuideDialog = false }) {
                        Text(stringResource(R.string.compass_done_btn))
                    }
                }
            },
            dismissButton = {
                if (!telemetry.isBatteryOptimizationIgnored) {
                    TextButton(onClick = { showGojekGuideDialog = false }) {
                        Text(stringResource(R.string.compass_done_btn))
                    }
                }
            },
        )
    }
}

@Composable
private fun ActionGateCard(
    icon: ImageVector,
    title: String,
    description: String,
    buttonLabel: String,
    accentColor: Color,
    onClick: () -> Unit,
    buttonTestTag: String,
) {
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.5.dp,
                color = accentColor.copy(alpha = 0.65f),
                shape = MaterialTheme.shapes.large,
            ),
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                    )
                }
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag(buttonTestTag),
            ) {
                Text(
                    text = buttonLabel,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

@Composable
private fun HeroFixStatusCard(
    telemetry: GnssTelemetryState,
    settings: AppSettings,
    nowMillis: Long,
) {
    val fixState = telemetry.fixState
    val statusColor = when (fixState) {
        FixState.FIX_3D -> SignalEmerald
        FixState.FIX_2D, FixState.SEARCHING -> AmberSearch
        FixState.NO_PERMISSION, FixState.GPS_DISABLED -> AlertCrimson
    }
    val statusTitle = when (fixState) {
        FixState.FIX_3D -> stringResource(R.string.status_fix_3d)
        FixState.FIX_2D -> stringResource(R.string.status_fix_2d)
        FixState.SEARCHING -> stringResource(R.string.status_searching)
        FixState.GPS_DISABLED -> stringResource(R.string.status_gps_disabled)
        FixState.NO_PERMISSION -> stringResource(R.string.status_no_permission)
    }
    val statusDesc = when (fixState) {
        FixState.FIX_3D -> stringResource(R.string.status_desc_fix_3d)
        FixState.FIX_2D -> stringResource(R.string.status_desc_fix_2d)
        FixState.SEARCHING -> stringResource(R.string.status_desc_searching)
        FixState.GPS_DISABLED -> stringResource(R.string.status_desc_gps_disabled)
        FixState.NO_PERMISSION -> stringResource(R.string.status_desc_no_permission)
    }

    val timerLabel = if (telemetry.locationFix != null) {
        stringResource(R.string.label_fix_age)
    } else {
        stringResource(R.string.label_elapsed)
    }
    val timerValue = when {
        telemetry.locationFix != null -> {
            Formatters.formatDurationSeconds(nowMillis - telemetry.locationFix.timestampMillis)
        }
        fixState == FixState.SEARCHING -> {
            Formatters.formatDurationSeconds(nowMillis - telemetry.searchStartedAtMillis)
        }
        else -> "—"
    }

    Card(
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
        ),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = statusColor.copy(alpha = 0.45f),
                shape = MaterialTheme.shapes.extraLarge,
            ),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            statusColor.copy(alpha = 0.12f),
                            Color.Transparent,
                        )
                    )
                )
                .padding(18.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    PulseStatusOrb(fixState = fixState, color = statusColor)

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = statusTitle,
                            style = MaterialTheme.typography.headlineSmall,
                            color = statusColor,
                            modifier = Modifier.testTag("fix_status_title"),
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = statusDesc,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                if (telemetry.hasLocationPermission && telemetry.isGpsProviderEnabled) {
                    val grade = telemetry.signalGrade
                    val gradeColor = when (grade) {
                        GnssSignalGrade.ULTRA_STRONG -> SignalEmerald
                        GnssSignalGrade.STRONG -> TelemetryCyan
                        GnssSignalGrade.MODERATE -> AmberSearch
                        GnssSignalGrade.WEAK -> AlertCrimson
                    }
                    val gradeText = when (grade) {
                        GnssSignalGrade.ULTRA_STRONG -> stringResource(R.string.gnss_grade_ultra)
                        GnssSignalGrade.STRONG -> stringResource(R.string.gnss_grade_strong)
                        GnssSignalGrade.MODERATE -> stringResource(R.string.gnss_grade_moderate)
                        GnssSignalGrade.WEAK -> stringResource(R.string.gnss_grade_weak)
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = gradeColor.copy(alpha = 0.14f),
                            modifier = Modifier
                                .border(
                                    width = 1.dp,
                                    color = gradeColor.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(999.dp),
                                )
                                .testTag("gnss_signal_grade_badge"),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(gradeColor),
                                )
                                Text(
                                    text = gradeText,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = gradeColor,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }

                        if (telemetry.isGnssEngineRunning) {
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = TelemetryCyan.copy(alpha = 0.12f),
                                modifier = Modifier.testTag("gnss_turbo_engine_badge"),
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Bolt,
                                        contentDescription = null,
                                        tint = TelemetryCyan,
                                        modifier = Modifier.size(14.dp),
                                    )
                                    Text(
                                        text = stringResource(R.string.gnss_engine_turbo_badge),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TelemetryCyan,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }
                }

                // 4 Key Instrument Pills
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    HeroMetricPill(
                        label = stringResource(R.string.label_ttff),
                        value = Formatters.formatTtff(telemetry.ttffMillis),
                        accent = statusColor,
                        modifier = Modifier.weight(1f),
                    )
                    HeroMetricPill(
                        label = stringResource(R.string.label_satellites),
                        value = "${telemetry.usedSatelliteCount}/${telemetry.visibleSatelliteCount}",
                        accent = TelemetryCyan,
                        modifier = Modifier.weight(1f),
                    )
                    HeroMetricPill(
                        label = stringResource(R.string.label_accuracy),
                        value = Formatters.formatAccuracy(
                            telemetry.locationFix?.accuracyMeters,
                            settings.distanceUnit,
                        ),
                        accent = statusColor,
                        modifier = Modifier.weight(1f),
                    )
                    HeroMetricPill(
                        label = timerLabel,
                        value = timerValue,
                        accent = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

@Composable
private fun PulseStatusOrb(
    fixState: FixState,
    color: Color,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "pulse_scale",
    )

    val icon = when (fixState) {
        FixState.FIX_3D -> Icons.Rounded.GpsFixed
        FixState.FIX_2D -> Icons.Rounded.GpsNotFixed
        FixState.SEARCHING -> Icons.Rounded.LocationSearching
        FixState.GPS_DISABLED, FixState.NO_PERMISSION -> Icons.Rounded.GpsOff
    }

    Box(
        modifier = Modifier.size(62.dp),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val radius = size.minDimension / 2f
            if (fixState == FixState.SEARCHING) {
                drawCircle(
                    color = color.copy(alpha = (1f - pulse) * 0.45f),
                    radius = radius * (0.55f + 0.45f * pulse),
                    style = Stroke(width = 2.5.dp.toPx()),
                )
            } else if (fixState == FixState.FIX_3D || fixState == FixState.FIX_2D) {
                drawCircle(
                    color = color.copy(alpha = 0.35f),
                    radius = radius * 0.94f,
                    style = Stroke(width = 2.dp.toPx()),
                )
            }
            drawCircle(
                color = color.copy(alpha = 0.16f),
                radius = radius * 0.72f,
            )
        }
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(26.dp),
        )
    }
}

@Composable
private fun HeroMetricPill(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = modifier,
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 9.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = label.uppercase(Locale.US),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = value,
                style = TabularMonoStyle.copy(
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                ),
                color = accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun CoordinatesCard(
    telemetry: GnssTelemetryState,
    settings: AppSettings,
    onCycleFormat: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onOpenMap: () -> Unit,
) {
    val fix = telemetry.locationFix

    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
                shape = MaterialTheme.shapes.large,
            ),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.label_coordinates),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onCycleFormat)
                        .testTag("cycle_coord_format_button"),
                ) {
                    Text(
                        text = settings.coordFormat.label,
                        style = TabularMonoStyle.copy(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                        ),
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                CoordinateValueRow(
                    label = stringResource(R.string.label_latitude),
                    value = fix?.let {
                        Formatters.formatCoordinate(it.latitude, isLatitude = true, settings.coordFormat)
                    } ?: "—",
                )
                CoordinateValueRow(
                    label = stringResource(R.string.label_longitude),
                    value = fix?.let {
                        Formatters.formatCoordinate(it.longitude, isLatitude = false, settings.coordFormat)
                    } ?: "—",
                )
                if (fix == null && telemetry.assistCoarseFix != null) {
                    val coarse = telemetry.assistCoarseFix
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = stringResource(R.string.coarse_assist_label),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                text = String.format(
                                    Locale.US,
                                    "%.4f, %.4f (±%.0fm)",
                                    coarse.latitude,
                                    coarse.longitude,
                                    coarse.accuracyMeters ?: 0f,
                                ),
                                style = TabularMonoStyle.copy(fontSize = 11.sp),
                                color = TelemetryCyan,
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilledTonalButton(
                    onClick = onCopy,
                    enabled = fix != null,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("copy_coords_button"),
                ) {
                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(stringResource(R.string.btn_copy_coords), maxLines = 1)
                }
                FilledTonalButton(
                    onClick = onShare,
                    enabled = fix != null,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("share_coords_button"),
                ) {
                    Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(stringResource(R.string.btn_share_coords), maxLines = 1)
                }
                FilledTonalButton(
                    onClick = onOpenMap,
                    enabled = fix != null,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("open_map_button"),
                ) {
                    Icon(Icons.Rounded.Map, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(stringResource(R.string.btn_open_map), maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun CoordinateValueRow(
    label: String,
    value: String,
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = value,
                style = TabularMonoStyle.copy(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                ),
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

@Composable
private fun TelemetryGrid(
    telemetry: GnssTelemetryState,
    settings: AppSettings,
) {
    val fix = telemetry.locationFix
    val dop = telemetry.dop

    val altValue = Formatters.formatAltitude(
        fix?.mslAltitudeMeters ?: fix?.altitudeMeters,
        settings.distanceUnit,
    )
    val altSub = buildString {
        if (fix?.mslAltitudeMeters != null && fix.altitudeMeters != null) {
            append("WGS84 ")
            append(Formatters.formatAltitude(fix.altitudeMeters, settings.distanceUnit))
        } else if (fix?.verticalAccuracyMeters != null) {
            append("V-Acc ")
            append(Formatters.formatAccuracy(fix.verticalAccuracyMeters, settings.distanceUnit))
        } else {
            append("MSL / Ellipsoid")
        }
    }

    val dopValue = if (dop.hdop != null || dop.pdop != null || dop.vdop != null) {
        String.format(
            Locale.US,
            "H %.1f · P %.1f",
            dop.hdop ?: 0f,
            dop.pdop ?: 0f,
        )
    } else "—"
    val dopSub = if (dop.vdop != null) {
        String.format(Locale.US, "VDOP %.1f", dop.vdop)
    } else {
        "HDOP / PDOP / VDOP"
    }

    val tiles = listOf(
        TelemetryTileData(
            icon = Icons.Rounded.Height,
            title = stringResource(R.string.label_altitude),
            value = altValue,
            subtitle = altSub,
            accent = TelemetryCyan,
        ),
        TelemetryTileData(
            icon = Icons.Rounded.Speed,
            title = stringResource(R.string.label_speed),
            value = Formatters.formatSpeed(fix?.speedMps, settings.speedUnit),
            subtitle = fix?.speedAccuracyMps?.let {
                "Acc " + Formatters.formatSpeed(it, settings.speedUnit)
            } ?: "Ground velocity",
            accent = SignalEmerald,
        ),
        TelemetryTileData(
            icon = Icons.Rounded.Explore,
            title = stringResource(R.string.label_bearing),
            value = Formatters.formatBearing(fix?.bearingDeg),
            subtitle = fix?.bearingAccuracyDeg?.let {
                String.format(Locale.US, "±%.0f°", it)
            } ?: "True north heading",
            accent = AmberSearch,
        ),
        TelemetryTileData(
            icon = Icons.Rounded.CompassCalibration,
            title = stringResource(R.string.label_dop),
            value = dopValue,
            subtitle = dopSub,
            accent = MaterialTheme.colorScheme.secondary,
        ),
        TelemetryTileData(
            icon = if (telemetry.isNetworkOnline) Icons.Rounded.Wifi else Icons.Rounded.WifiOff,
            title = stringResource(R.string.label_agps_net),
            value = if (telemetry.isNetworkOnline) "ONLINE" else "OFFLINE",
            subtitle = if (telemetry.isNetworkOnline) "NTP / XTRA ready" else "Standalone GNSS",
            accent = if (telemetry.isNetworkOnline) SignalEmerald else AmberSearch,
        ),
        TelemetryTileData(
            icon = Icons.Rounded.Memory,
            title = stringResource(R.string.label_dual_freq),
            value = if (telemetry.supportsDualFrequency) "L1 + L5" else "L1 / Single",
            subtitle = telemetry.gnssHardwareModel ?: "Hardware GNSS",
            accent = TelemetryCyan,
        ),
    )

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
        val columns = if (maxWidth >= 560.dp) 3 else 2
        val rows = tiles.chunked(columns)
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            rows.forEach { rowTiles ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    rowTiles.forEach { tile ->
                        TelemetryCard(
                            data = tile,
                            modifier = Modifier.weight(1f),
                        )
                    }
                    repeat(columns - rowTiles.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

private data class TelemetryTileData(
    val icon: ImageVector,
    val title: String,
    val value: String,
    val subtitle: String,
    val accent: Color,
)

@Composable
private fun TelemetryCard(
    data: TelemetryTileData,
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier.border(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant,
            shape = MaterialTheme.shapes.medium,
        ),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(
                    imageVector = data.icon,
                    contentDescription = null,
                    tint = data.accent,
                    modifier = Modifier.size(16.dp),
                )
                Text(
                    text = data.title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                text = data.value,
                style = TabularMonoStyle.copy(
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                ),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = data.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun BackgroundLockCard(
    isEnabled: Boolean,
    isServiceActive: Boolean,
    onToggle: () -> Unit,
) {
    val active = isEnabled && isServiceActive
    val accent = if (active) SignalEmerald else MaterialTheme.colorScheme.onSurfaceVariant

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (active) SignalEmerald.copy(alpha = 0.45f) else MaterialTheme.colorScheme.outlineVariant,
                shape = MaterialTheme.shapes.medium,
            ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(accent),
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.bg_lock_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = if (isEnabled) {
                        stringResource(R.string.bg_lock_desc_active)
                    } else {
                        stringResource(R.string.bg_lock_desc_inactive)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(
                checked = isEnabled,
                onCheckedChange = { onToggle() },
                modifier = Modifier.testTag("background_lock_switch"),
            )
        }
    }
}

@Composable
private fun LockNotificationCard(
    isEnabled: Boolean,
    hasNotificationPermission: Boolean,
    onToggle: () -> Unit,
    onRequestPermission: () -> Unit,
) {
    val active = isEnabled && hasNotificationPermission
    val accent = when {
        !hasNotificationPermission -> AmberSearch
        active -> TelemetryCyan
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = if (active) TelemetryCyan.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outlineVariant,
                shape = MaterialTheme.shapes.medium,
            ),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(
                imageVector = if (active) Icons.Rounded.NotificationsActive else Icons.Rounded.NotificationsOff,
                contentDescription = stringResource(R.string.lock_notif_toggle_title),
                tint = accent,
                modifier = Modifier.size(20.dp),
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.lock_notif_toggle_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = if (!hasNotificationPermission) {
                        stringResource(R.string.lock_notif_perm_needed)
                    } else {
                        stringResource(R.string.lock_notif_toggle_desc)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (!hasNotificationPermission) {
                FilledTonalButton(
                    onClick = onRequestPermission,
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("allow_lock_notification_button"),
                ) {
                    Text(stringResource(R.string.lock_notif_btn_allow))
                }
            } else {
                Switch(
                    checked = isEnabled,
                    onCheckedChange = { onToggle() },
                    modifier = Modifier.testTag("lock_notification_switch"),
                )
            }
        }
    }
}

@Composable
private fun CompassQuickCard(
    compass: CompassState,
    onOpenCompass: () -> Unit,
    onOpenCalibration: () -> Unit,
) {
    val accColor = compassAccuracyColor(compass.accuracy)
    val accLabel = compassAccuracyText(compass.accuracy)
    val needsCalibration = compass.accuracy == CompassAccuracy.LOW || compass.accuracy == CompassAccuracy.UNRELIABLE

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onOpenCompass)
            .border(
                width = 1.dp,
                color = if (needsCalibration) accColor.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outlineVariant,
                shape = MaterialTheme.shapes.medium,
            )
            .testTag("dashboard_compass_card"),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(accColor.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Explore,
                    contentDescription = stringResource(R.string.tab_compass),
                    tint = accColor,
                    modifier = Modifier.size(22.dp),
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = stringResource(R.string.tab_compass),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = Formatters.formatBearing(compass.azimuthDeg),
                        style = TabularMonoStyle.copy(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                        ),
                        color = TelemetryCyan,
                    )
                    compass.magneticFieldMicroTesla?.let { ut ->
                        Text(
                            text = String.format(Locale.US, "%.0f µT", ut),
                            style = TabularMonoStyle.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Text(
                    text = accLabel,
                    style = MaterialTheme.typography.bodySmall,
                    color = accColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            FilledTonalButton(
                onClick = onOpenCalibration,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier
                    .height(48.dp)
                    .testTag("dashboard_calibrate_compass_button"),
            ) {
                Icon(
                    imageVector = Icons.Rounded.CompassCalibration,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.compass_calibrate_btn),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun PriorityBindingCard(
    isBatteryUnrestricted: Boolean,
    selectedPackage: String?,
    installedApps: List<PriorityAppInfo>,
    onOpenBatterySettings: () -> Unit,
    onChooseApp: () -> Unit,
    onBindAndLaunch: () -> Unit,
    onQuickBindDriver: (String) -> Unit,
    onDriverNotInstalled: (String) -> Unit,
    onShowDriverGuide: () -> Unit,
) {
    val selectedLabel = installedApps.find { it.packageName == selectedPackage }?.label
        ?: stringResource(R.string.priority_app_none)
    val driverMatches = remember(installedApps) {
        PriorityAppHelper.matchDriverPlatforms(installedApps)
    }
    val batteryAccent = if (isBatteryUnrestricted) SignalEmerald else AmberSearch

    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
                shape = MaterialTheme.shapes.medium,
            )
            .testTag("priority_binding_card"),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Text(
                        text = stringResource(R.string.priority_bind_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = stringResource(R.string.priority_bind_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Battery optimization unrestricted status row
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = batteryAccent.copy(alpha = 0.12f),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(
                            imageVector = if (isBatteryUnrestricted) {
                                Icons.Rounded.VerifiedUser
                            } else {
                                Icons.Rounded.WarningAmber
                            },
                            contentDescription = null,
                            tint = batteryAccent,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(
                            text = if (isBatteryUnrestricted) {
                                stringResource(R.string.priority_battery_ok)
                            } else {
                                stringResource(R.string.priority_battery_restricted)
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = batteryAccent,
                        )
                    }
                    if (!isBatteryUnrestricted) {
                        TextButton(
                            onClick = onOpenBatterySettings,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("battery_unrestricted_button"),
                        ) {
                            Text(stringResource(R.string.priority_battery_fix_btn))
                        }
                    }
                }
            }

            // Selected priority app row
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.priority_app_label),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            text = selectedLabel,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    OutlinedButton(
                        onClick = onChooseApp,
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("choose_priority_app_button"),
                    ) {
                        Text(stringResource(R.string.priority_app_change))
                    }
                }
            }

            // Quick-bind buttons for Gojek Driver, Grab Driver, Shopee Driver, Maxim Driver, inDrive
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = stringResource(R.string.priority_drivers_quick_label),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    DriverQuickBindButton(
                        match = driverMatches[0],
                        selectedPackage = selectedPackage,
                        onQuickBind = onQuickBindDriver,
                        onNotInstalled = onDriverNotInstalled,
                        modifier = Modifier.weight(1f),
                    )
                    DriverQuickBindButton(
                        match = driverMatches[1],
                        selectedPackage = selectedPackage,
                        onQuickBind = onQuickBindDriver,
                        onNotInstalled = onDriverNotInstalled,
                        modifier = Modifier.weight(1f),
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    DriverQuickBindButton(
                        match = driverMatches[2],
                        selectedPackage = selectedPackage,
                        onQuickBind = onQuickBindDriver,
                        onNotInstalled = onDriverNotInstalled,
                        modifier = Modifier.weight(1f),
                    )
                    DriverQuickBindButton(
                        match = driverMatches[3],
                        selectedPackage = selectedPackage,
                        onQuickBind = onQuickBindDriver,
                        onNotInstalled = onDriverNotInstalled,
                        modifier = Modifier.weight(1f),
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    DriverQuickBindButton(
                        match = driverMatches[4],
                        selectedPackage = selectedPackage,
                        onQuickBind = onQuickBindDriver,
                        onNotInstalled = onDriverNotInstalled,
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedButton(
                        onClick = onShowDriverGuide,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("driver_guide_button"),
                    ) {
                        Text(
                            text = stringResource(R.string.priority_gojek_guide_btn),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }

            Button(
                onClick = onBindAndLaunch,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("launch_priority_app_button"),
            ) {
                Icon(
                    imageVector = Icons.Rounded.OpenInNew,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.priority_app_launch_btn),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun DriverQuickBindButton(
    match: DriverPresetMatch,
    selectedPackage: String?,
    onQuickBind: (String) -> Unit,
    onNotInstalled: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val installed = match.installedApp
    val tag = "quick_bind_${match.platform.name.lowercase(Locale.US)}_button"
    if (installed != null) {
        val isSelected = installed.packageName == selectedPackage
        FilledTonalButton(
            onClick = { onQuickBind(installed.packageName) },
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = modifier
                .height(48.dp)
                .then(
                    if (isSelected) {
                        Modifier.border(
                            width = 1.5.dp,
                            color = SignalEmerald,
                            shape = RoundedCornerShape(24.dp),
                        )
                    } else {
                        Modifier
                    }
                )
                .testTag(tag),
        ) {
            Icon(
                imageVector = if (isSelected) Icons.Rounded.CheckCircle else Icons.Rounded.Bolt,
                contentDescription = null,
                tint = if (isSelected) SignalEmerald else TelemetryCyan,
                modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = match.platform.displayName,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    } else {
        OutlinedButton(
            onClick = { onNotInstalled(match.platform.displayName) },
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = modifier
                .height(48.dp)
                .testTag(tag),
        ) {
            Text(
                text = match.platform.displayName,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun PriorityAppPickerDialog(
    selectedPackage: String?,
    installedApps: List<PriorityAppInfo>,
    onSelect: (String?) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.priority_app_dialog_title)) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onSelect(null) }
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(
                        selected = selectedPackage == null,
                        onClick = { onSelect(null) },
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.priority_app_none),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }

                if (installedApps.isEmpty()) {
                    Text(
                        text = stringResource(R.string.priority_app_dialog_empty),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                } else {
                    installedApps.forEach { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onSelect(app.packageName) }
                                .padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(
                                selected = selectedPackage == app.packageName,
                                onClick = { onSelect(app.packageName) },
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = app.label,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                                Text(
                                    text = app.packageName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.btn_cancel))
            }
        },
    )
}
