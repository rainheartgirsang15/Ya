package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.SpeedUnit
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.AmberSearch
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.TabularMonoStyle
import com.example.ui.theme.TelemetryCyan
import com.example.util.Formatters
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpeedometerCard(
    speedMps: Float?,
    speedAccuracyMps: Float?,
    maxSpeedMps: Float,
    hasFix: Boolean,
    selectedUnit: SpeedUnit,
    onSelectUnit: (SpeedUnit) -> Unit,
    onResetPeak: () -> Unit,
    modifier: Modifier = Modifier,
) {
    // Speedometer gauge specifically displays km/h or mph
    val gaugeUnit = if (selectedUnit == SpeedUnit.MPH) SpeedUnit.MPH else SpeedUnit.KMH
    val currentValue = speedMps?.let { Formatters.convertSpeed(it, gaugeUnit) } ?: 0f
    val peakValue = Formatters.convertSpeed(maxSpeedMps.coerceAtLeast(0f), gaugeUnit)
    val speedAccText = speedAccuracyMps?.let {
        String.format(Locale.US, "±%.1f %s", Formatters.convertSpeed(it, gaugeUnit), gaugeUnit.label)
    }

    val maxScale = selectSpeedScaleMax(
        observedMax = maxOf(currentValue, peakValue),
        unit = gaugeUnit,
    )

    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
                shape = MaterialTheme.shapes.large,
            )
            .testTag("speedometer_card"),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(TelemetryCyan.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Speed,
                            contentDescription = null,
                            tint = TelemetryCyan,
                            modifier = Modifier.size(19.dp),
                        )
                    }
                    Text(
                        text = stringResource(R.string.speedometer_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = gaugeUnit == SpeedUnit.KMH,
                        onClick = { onSelectUnit(SpeedUnit.KMH) },
                        label = { Text(SpeedUnit.KMH.label) },
                        modifier = Modifier.testTag("speedometer_unit_kmh"),
                    )
                    FilterChip(
                        selected = gaugeUnit == SpeedUnit.MPH,
                        onClick = { onSelectUnit(SpeedUnit.MPH) },
                        label = { Text(SpeedUnit.MPH.label) },
                        modifier = Modifier.testTag("speedometer_unit_mph"),
                    )
                }
            }

            BoxWithConstraints(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center,
            ) {
                val gaugeSize = if (maxWidth < 250.dp) maxWidth else 250.dp
                SpeedometerCircularGauge(
                    speedValue = if (hasFix && speedMps != null) currentValue else 0f,
                    hasReading = hasFix && speedMps != null,
                    maxScale = maxScale,
                    unitLabel = gaugeUnit.label,
                    accuracyText = speedAccText,
                    modifier = Modifier
                        .size(gaugeSize)
                        .aspectRatio(1f)
                        .testTag("speedometer_gauge"),
                )
            }

            // Peak Speed & Movement Status Strip
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(
                            text = stringResource(R.string.speedometer_peak),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            text = String.format(Locale.US, "%.1f %s", peakValue, gaugeUnit.label),
                            style = TabularMonoStyle.copy(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                            ),
                            color = SignalEmerald,
                            modifier = Modifier.testTag("speedometer_peak_value"),
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val statusText = when {
                            !hasFix -> stringResource(R.string.speedometer_waiting)
                            currentValue < 0.5f -> stringResource(R.string.speedometer_stationary)
                            else -> null
                        }
                        if (statusText != null) {
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (maxSpeedMps > 0f) {
                            Spacer(modifier = Modifier.width(4.dp))
                            IconButton(
                                onClick = onResetPeak,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("speedometer_reset_peak_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = stringResource(R.string.speedometer_peak),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SpeedometerCircularGauge(
    speedValue: Float,
    hasReading: Boolean,
    maxScale: Float,
    unitLabel: String,
    accuracyText: String?,
    modifier: Modifier = Modifier,
) {
    val safeMax = maxScale.coerceAtLeast(1f)
    val clampedSpeed = speedValue.coerceIn(0f, safeMax)
    val animatedSpeed by animateFloatAsState(
        targetValue = clampedSpeed,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMediumLow,
        ),
        label = "speedometer_needle",
    )

    val textMeasurer = rememberTextMeasurer()
    val trackColor = MaterialTheme.colorScheme.surfaceContainerHighest
    val majorTickColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.78f)
    val minorTickColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
    val scaleTextColor = MaterialTheme.colorScheme.onSurfaceVariant
    val needleColor = AlertCrimson
    val pivotOuterColor = MaterialTheme.colorScheme.onSurface
    val pivotInnerColor = MaterialTheme.colorScheme.surface
    val readoutColor = if (hasReading) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant

    val fraction = (animatedSpeed / safeMax).coerceIn(0f, 1f)
    val activeAccent = when {
        fraction < 0.35f -> TelemetryCyan
        fraction < 0.70f -> SignalEmerald
        fraction < 0.88f -> AmberSearch
        else -> AlertCrimson
    }

    val cdText = if (hasReading) {
        String.format(Locale.US, "Speedometer %.1f %s", speedValue, unitLabel)
    } else {
        "Speedometer waiting for GPS fix"
    }

    Box(
        modifier = modifier.semantics { contentDescription = cdText },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val startAngle = 135f
            val totalSweep = 270f
            val cx = size.width / 2f
            val cy = size.height / 2f
            val center = Offset(cx, cy)
            val strokeWidth = 14.dp.toPx()
            val arcRadius = (minOf(size.width, size.height) / 2f) - strokeWidth
            val arcTopLeft = Offset(cx - arcRadius, cy - arcRadius)
            val arcSize = Size(arcRadius * 2f, arcRadius * 2f)

            // Subtle dial backing
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        activeAccent.copy(alpha = if (hasReading && fraction > 0.02f) 0.10f else 0.03f),
                        Color.Transparent,
                    ),
                    center = center,
                    radius = arcRadius,
                ),
                radius = arcRadius,
                center = center,
            )

            // Background arc track
            drawArc(
                color = trackColor,
                startAngle = startAngle,
                sweepAngle = totalSweep,
                useCenter = false,
                topLeft = arcTopLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            )

            // Active speed arc with gradient aligned cleanly to 135° start angle
            val activeSweep = (totalSweep * fraction).coerceAtLeast(0f)
            if (activeSweep > 0.5f) {
                rotate(degrees = startAngle, pivot = center) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            0.0f to TelemetryCyan,
                            0.25f to SignalEmerald,
                            0.52f to AmberSearch,
                            0.75f to AlertCrimson,
                            0.85f to AlertCrimson,
                            0.94f to TelemetryCyan,
                            1.0f to TelemetryCyan,
                            center = center,
                        ),
                        startAngle = 0f,
                        sweepAngle = activeSweep,
                        useCenter = false,
                        topLeft = arcTopLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                    )
                }
            }

            // Major & minor ticks + numeric scale labels
            val majorSegments = 6
            val minorPerMajor = 4
            val totalMinor = majorSegments * minorPerMajor
            val labelStyle = TextStyle(
                fontFamily = JetBrainsMonoFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 10.sp,
                color = scaleTextColor,
            )

            for (i in 0..totalMinor) {
                val t = i.toFloat() / totalMinor
                val angleDeg = startAngle + totalSweep * t
                val rad = Math.toRadians(angleDeg.toDouble())
                val cosA = cos(rad).toFloat()
                val sinA = sin(rad).toFloat()

                val isMajor = i % minorPerMajor == 0
                val outerR = arcRadius - strokeWidth * 0.65f
                val innerR = outerR - if (isMajor) 10.dp.toPx() else 5.dp.toPx()

                drawLine(
                    color = if (isMajor) majorTickColor else minorTickColor,
                    start = Offset(cx + innerR * cosA, cy + innerR * sinA),
                    end = Offset(cx + outerR * cosA, cy + outerR * sinA),
                    strokeWidth = if (isMajor) 2.dp.toPx() else 1.dp.toPx(),
                    cap = StrokeCap.Round,
                )

                if (isMajor) {
                    val labelValue = ((safeMax / majorSegments) * (i / minorPerMajor)).toInt()
                    val measured = textMeasurer.measure(labelValue.toString(), labelStyle)
                    val textR = innerR - 13.dp.toPx()
                    drawText(
                        textLayoutResult = measured,
                        topLeft = Offset(
                            x = cx + textR * cosA - measured.size.width / 2f,
                            y = cy + textR * sinA - measured.size.height / 2f,
                        ),
                    )
                }
            }

            // Tapered precision needle (Canvas rotation uses 0° = 3 o'clock, and our arc starts at 135° = 7:30)
            val needleAngleDeg = startAngle + totalSweep * fraction
            rotate(degrees = needleAngleDeg, pivot = center) {
                val tipLength = arcRadius - strokeWidth * 0.9f
                val tailLength = 16.dp.toPx()
                val halfBase = 3.2.dp.toPx()
                val needlePath = Path().apply {
                    moveTo(cx + tipLength, cy)
                    lineTo(cx - tailLength, cy - halfBase)
                    lineTo(cx - tailLength, cy + halfBase)
                    close()
                }
                drawPath(path = needlePath, color = needleColor)
            }

            // Center pivot hub
            drawCircle(
                color = pivotOuterColor,
                radius = 8.dp.toPx(),
                center = center,
            )
            drawCircle(
                color = pivotInnerColor,
                radius = 3.5.dp.toPx(),
                center = center,
            )
        }

        // Digital readout positioned cleanly in the lower open-arc cutout
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = if (hasReading) String.format(Locale.US, "%.1f", speedValue) else "—",
                style = TabularMonoStyle.copy(
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                ),
                color = readoutColor,
                modifier = Modifier.testTag("speedometer_digital_value"),
            )
            Text(
                text = unitLabel,
                style = TabularMonoStyle.copy(
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                ),
                color = activeAccent,
            )
            if (accuracyText != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = accuracyText,
                    style = TabularMonoStyle.copy(fontSize = 10.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

fun selectSpeedScaleMax(observedMax: Float, unit: SpeedUnit): Float {
    return if (unit == SpeedUnit.MPH) {
        when {
            observedMax <= 40f -> 40f
            observedMax <= 80f -> 80f
            observedMax <= 120f -> 120f
            observedMax <= 160f -> 160f
            else -> 200f
        }
    } else {
        when {
            observedMax <= 60f -> 60f
            observedMax <= 120f -> 120f
            observedMax <= 180f -> 180f
            observedMax <= 240f -> 240f
            else -> 320f
        }
    }
}
