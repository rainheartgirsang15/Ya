package com.example.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.GnssApp
import com.example.MainActivity
import com.example.R
import com.example.data.PriorityAppHelper
import com.example.model.FixState
import com.example.model.GnssTelemetryState
import com.example.util.Formatters
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.Granularity
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

class GnssLockService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var isFusedClientRegistered = false
    private var collectorJob: Job? = null
    private var watchdogJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastNotificationUpdateMillis = 0L
    private var lastNotifiedFixState: FixState? = null

    private val serviceLocationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val location = result.lastLocation ?: return
            val app = application as GnssApp
            app.gnssRepository.onFusedLocation(location)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as GnssApp
        val gnssRepo = app.gnssRepository
        val settingsRepo = app.settingsRepository

        if (intent?.action == ACTION_STOP) {
            serviceScope.launch {
                settingsRepo.setBackgroundLockEnabled(false)
            }
            stopPersistentFusedLocation()
            watchdogJob?.cancel()
            watchdogJob = null
            collectorJob?.cancel()
            collectorJob = null
            gnssRepo.setBackgroundServiceActive(false)
            gnssRepo.stopTracking()
            releaseWakeLock()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        if (!hasLocationPermission()) {
            gnssRepo.setBackgroundServiceActive(false)
            stopSelf()
            return START_NOT_STICKY
        }

        val initialNotification = buildNotification(gnssRepo.state.value, priorityPackage = null)
        val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, initialNotification, serviceType)

        acquireWakeLock()
        gnssRepo.setBackgroundServiceActive(true)
        gnssRepo.startTracking()
        startPersistentFusedLocation()

        if (collectorJob == null) {
            collectorJob = serviceScope.launch {
                combine(
                    gnssRepo.state,
                    settingsRepo.settingsFlow,
                ) { state, settings ->
                    state to settings.priorityAppPackage
                }.collectLatest { (state, priorityPkg) ->
                    val now = System.currentTimeMillis()
                    val stateChanged = state.fixState != lastNotifiedFixState
                    if (stateChanged || now - lastNotificationUpdateMillis >= 1200L) {
                        lastNotifiedFixState = state.fixState
                        lastNotificationUpdateMillis = now
                        val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                        mgr.notify(NOTIFICATION_ID, buildNotification(state, priorityPkg))
                    }
                }
            }
        }

        if (watchdogJob == null) {
            watchdogJob = serviceScope.launch {
                while (isActive) {
                    delay(10_000L)
                    gnssRepo.recoverStalledLockIfNeeded(15_000L)
                }
            }
        }

        return START_STICKY
    }

    override fun onDestroy() {
        val app = application as GnssApp
        stopPersistentFusedLocation()
        app.gnssRepository.setBackgroundServiceActive(false)
        watchdogJob?.cancel()
        watchdogJob = null
        collectorJob?.cancel()
        collectorJob = null
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }

    @SuppressLint("MissingPermission")
    private fun startPersistentFusedLocation() {
        if (isFusedClientRegistered || !hasLocationPermission()) return
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(500L)
            .setMinUpdateDistanceMeters(0f)
            .setMaxUpdateDelayMillis(0L)
            .setGranularity(Granularity.GRANULARITY_FINE)
            .setWaitForAccurateLocation(false)
            .build()

        runCatching {
            fusedLocationClient.requestLocationUpdates(
                request,
                serviceLocationCallback,
                Looper.getMainLooper(),
            )
            isFusedClientRegistered = true
        }
    }

    private fun stopPersistentFusedLocation() {
        if (!isFusedClientRegistered) return
        runCatching {
            fusedLocationClient.removeLocationUpdates(serviceLocationCallback)
        }
        isFusedClientRegistered = false
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GnssFix::BackgroundLock").apply {
            setReferenceCounted(false)
            acquire(4 * 60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        }
        wakeLock = null
    }

    private fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "GNSS Background Lock",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Keeps GNSS/GPS hardware locked while using other apps"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(
        state: GnssTelemetryState,
        priorityPackage: String?,
    ): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val stopIntent = Intent(this, GnssLockService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val title = when (state.fixState) {
            FixState.FIX_3D -> getString(R.string.status_fix_3d)
            FixState.FIX_2D -> getString(R.string.status_fix_2d)
            FixState.SEARCHING -> getString(R.string.status_searching)
            FixState.GPS_DISABLED -> getString(R.string.status_gps_disabled)
            FixState.NO_PERMISSION -> getString(R.string.status_no_permission)
        }

        val satsText = "Sats ${state.usedSatelliteCount}/${state.visibleSatelliteCount}"
        val fix = state.locationFix
        val body = if (fix != null) {
            val acc = fix.accuracyMeters?.let { String.format(Locale.US, "±%.1fm", it) } ?: ""
            val ttff = Formatters.formatTtff(state.ttffMillis)
            String.format(
                Locale.US,
                "%s · %s · %.5f, %.5f (TTFF %s)",
                satsText,
                acc,
                fix.latitude,
                fix.longitude,
                ttff,
            )
        } else {
            "$satsText · Holding GNSS hardware active"
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.gnss_radar_icon)
            .setContentTitle(title)
            .setContentText(body)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openPending)
            .addAction(0, getString(R.string.bg_lock_stop), stopPending)

        if (!priorityPackage.isNullOrBlank()) {
            val launchIntent = packageManager.getLaunchIntentForPackage(priorityPackage)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val appLabel = PriorityAppHelper.resolveAppLabel(packageManager, priorityPackage)
                    ?: priorityPackage
                val openPriorityPending = PendingIntent.getActivity(
                    this,
                    2,
                    launchIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
                builder.addAction(0, getString(R.string.priority_notif_open_app, appLabel), openPriorityPending)
            }
        }

        return builder.build()
    }

    companion object {
        private const val CHANNEL_ID = "gnss_lock_channel"
        private const val NOTIFICATION_ID = 4101
        const val ACTION_START = "com.example.action.START_GNSS_LOCK"
        const val ACTION_STOP = "com.example.action.STOP_GNSS_LOCK"

        fun start(context: Context) {
            val intent = Intent(context, GnssLockService::class.java).apply {
                action = ACTION_START
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, GnssLockService::class.java))
        }
    }
}
