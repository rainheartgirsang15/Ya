package com.example.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.GnssRepository
import com.example.data.PriorityAppHelper
import com.example.data.SettingsRepository
import com.example.model.AppSettings
import com.example.model.FixState
import com.example.model.GnssTelemetryState
import com.example.util.Formatters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.util.Locale

class GnssLockNotifier(
    private val context: Context,
    private val gnssRepository: GnssRepository,
    private val settingsRepository: SettingsRepository,
) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var wasLocked = false

    fun startObserving() {
        createAlertChannel()
        scope.launch {
            combine(
                gnssRepository.state,
                settingsRepository.settingsFlow,
            ) { telemetry, settings ->
                telemetry to settings
            }.collect { (telemetry, settings) ->
                val isLockedNow = telemetry.locationFix != null &&
                    (telemetry.fixState == FixState.FIX_3D || telemetry.fixState == FixState.FIX_2D)

                if (isLockedNow && !wasLocked) {
                    wasLocked = true
                    if (settings.lockNotificationEnabled && hasNotificationPermission()) {
                        postLockAlertNotification(telemetry, settings)
                    }
                } else if (!isLockedNow) {
                    wasLocked = false
                }
            }
        }
    }

    private fun createAlertChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                ALERT_CHANNEL_ID,
                appContext.getString(R.string.lock_notif_channel_name),
                NotificationManager.IMPORTANCE_HIGH,
            ).apply {
                description = appContext.getString(R.string.lock_notif_channel_desc)
                enableVibration(true)
                setShowBadge(true)
            }
            val manager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    @SuppressLint("MissingPermission")
    private fun postLockAlertNotification(
        telemetry: GnssTelemetryState,
        settings: AppSettings,
    ) {
        val fix = telemetry.locationFix ?: return
        val openIntent = Intent(appContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            appContext,
            102,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val title = if (telemetry.fixState == FixState.FIX_3D) {
            appContext.getString(R.string.lock_notif_title_3d)
        } else {
            appContext.getString(R.string.lock_notif_title_2d)
        }

        val accText = Formatters.formatAccuracy(fix.accuracyMeters, settings.distanceUnit)
        val ttffText = Formatters.formatTtff(telemetry.ttffMillis)
        val latText = Formatters.formatCoordinate(fix.latitude, isLatitude = true, settings.coordFormat)
        val lonText = Formatters.formatCoordinate(fix.longitude, isLatitude = false, settings.coordFormat)

        val summary = String.format(
            Locale.US,
            "%s · %d/%d sat · TTFF %s",
            accText,
            telemetry.usedSatelliteCount,
            telemetry.visibleSatelliteCount,
            ttffText,
        )
        val expanded = "$summary\n$latText, $lonText"

        val builder = NotificationCompat.Builder(appContext, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.gnss_radar_icon)
            .setContentTitle(title)
            .setContentText(summary)
            .setStyle(NotificationCompat.BigTextStyle().bigText(expanded))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setContentIntent(openPending)

        val priorityPkg = settings.priorityAppPackage
        if (!priorityPkg.isNullOrBlank()) {
            val launchIntent = appContext.packageManager.getLaunchIntentForPackage(priorityPkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                val appLabel = PriorityAppHelper.resolveAppLabel(appContext.packageManager, priorityPkg)
                    ?: priorityPkg
                val openPriorityPending = PendingIntent.getActivity(
                    appContext,
                    103,
                    launchIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
                builder.addAction(0, appContext.getString(R.string.priority_notif_open_app, appLabel), openPriorityPending)
            }
        }

        val notification = builder.build()

        runCatching {
            NotificationManagerCompat.from(appContext).notify(ALERT_NOTIFICATION_ID, notification)
        }
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                appContext,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    companion object {
        private const val ALERT_CHANNEL_ID = "gnss_fix_alert_channel"
        private const val ALERT_NOTIFICATION_ID = 4102
    }
}
