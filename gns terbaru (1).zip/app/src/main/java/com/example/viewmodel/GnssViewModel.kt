package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.GnssApp
import com.example.data.PriorityAppHelper
import com.example.model.AppSettings
import com.example.model.CompassState
import com.example.model.Constellation
import com.example.model.CoordFormat
import com.example.model.DistanceUnit
import com.example.model.GnssTelemetryState
import com.example.model.NmeaType
import com.example.model.PriorityAppInfo
import com.example.model.SpeedUnit
import com.example.model.ThemeMode
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class GnssTab {
    FIX,
    SKYPLOT,
    SIGNALS,
    COMPASS,
    NMEA,
}

enum class SatelliteFilter {
    ALL,
    USED,
    GPS,
    GLONASS,
    GALILEO,
    BEIDOU,
    QZSS,
    SBAS,
}

class GnssViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as GnssApp
    private val gnssRepository = app.gnssRepository
    private val compassRepository = app.compassRepository
    private val settingsRepository = app.settingsRepository

    val telemetryState: StateFlow<GnssTelemetryState> = gnssRepository.state
    val compassState: StateFlow<CompassState> = compassRepository.state

    val settings: StateFlow<AppSettings> = settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    private val _selectedTab = MutableStateFlow(GnssTab.FIX)
    val selectedTab: StateFlow<GnssTab> = _selectedTab.asStateFlow()

    private val _satelliteFilter = MutableStateFlow(SatelliteFilter.ALL)
    val satelliteFilter: StateFlow<SatelliteFilter> = _satelliteFilter.asStateFlow()

    private val _nmeaFilter = MutableStateFlow<NmeaType?>(null)
    val nmeaFilter: StateFlow<NmeaType?> = _nmeaFilter.asStateFlow()

    private val _selectedSatelliteKey = MutableStateFlow<String?>(null)
    val selectedSatelliteKey: StateFlow<String?> = _selectedSatelliteKey.asStateFlow()

    private val _skyplotCompassAlign = MutableStateFlow(false)
    val skyplotCompassAlign: StateFlow<Boolean> = _skyplotCompassAlign.asStateFlow()

    private val _nowMillis = MutableStateFlow(System.currentTimeMillis())
    val nowMillis: StateFlow<Long> = _nowMillis.asStateFlow()

    private val _installedPriorityApps = MutableStateFlow(
        PriorityAppHelper.queryInstalledPriorityApps(application)
    )
    val installedPriorityApps: StateFlow<List<PriorityAppInfo>> = _installedPriorityApps.asStateFlow()

    init {
        viewModelScope.launch {
            while (true) {
                _nowMillis.value = System.currentTimeMillis()
                delay(200L)
            }
        }
    }

    fun startTracking() {
        gnssRepository.startTracking()
    }

    fun stopTracking() {
        if (!telemetryState.value.isBackgroundServiceActive) {
            gnssRepository.stopTracking()
        }
    }

    fun startCompass() {
        compassRepository.startListening()
    }

    fun stopCompass() {
        compassRepository.stopListening()
    }

    fun resampleCompassCalibration() {
        compassRepository.resampleCalibration()
    }

    fun toggleSkyplotCompassAlign() {
        _skyplotCompassAlign.value = !_skyplotCompassAlign.value
    }

    fun onPermissionResult() {
        gnssRepository.refreshEnvironmentStatus()
    }

    fun refreshStatus() {
        gnssRepository.refreshEnvironmentStatus()
        _installedPriorityApps.value = PriorityAppHelper.queryInstalledPriorityApps(app)
    }

    fun selectTab(tab: GnssTab) {
        _selectedTab.value = tab
    }

    fun selectSatelliteFilter(filter: SatelliteFilter) {
        _satelliteFilter.value = filter
    }

    fun selectNmeaFilter(type: NmeaType?) {
        _nmeaFilter.value = type
    }

    fun selectSatellite(key: String?) {
        _selectedSatelliteKey.value = if (_selectedSatelliteKey.value == key) null else key
    }

    fun boostAgpsFix() {
        gnssRepository.boostAgpsFix()
    }

    fun coldResetGnss() {
        gnssRepository.coldResetGnss()
    }

    fun clearAgpsFeedback() {
        gnssRepository.clearAgpsFeedback()
    }

    fun resetMaxSpeed() {
        gnssRepository.resetMaxSpeed()
    }

    fun toggleNmeaPaused() {
        gnssRepository.toggleNmeaPaused()
    }

    fun clearNmeaLogs() {
        gnssRepository.clearNmeaLogs()
    }

    fun cycleCoordFormat() {
        viewModelScope.launch {
            val next = when (settings.value.coordFormat) {
                CoordFormat.DECIMAL_DEGREES -> CoordFormat.DMS
                CoordFormat.DMS -> CoordFormat.DDM
                CoordFormat.DDM -> CoordFormat.DECIMAL_DEGREES
            }
            settingsRepository.setCoordFormat(next)
        }
    }

    fun setCoordFormat(format: CoordFormat) {
        viewModelScope.launch { settingsRepository.setCoordFormat(format) }
    }

    fun setSpeedUnit(unit: SpeedUnit) {
        viewModelScope.launch { settingsRepository.setSpeedUnit(unit) }
    }

    fun setDistanceUnit(unit: DistanceUnit) {
        viewModelScope.launch { settingsRepository.setDistanceUnit(unit) }
    }

    fun toggleKeepScreenOn() {
        viewModelScope.launch {
            settingsRepository.setKeepScreenOn(!settings.value.keepScreenOn)
        }
    }

    fun toggleBackgroundLock() {
        viewModelScope.launch {
            settingsRepository.setBackgroundLockEnabled(!settings.value.backgroundLockEnabled)
        }
    }

    fun toggleLockNotification() {
        viewModelScope.launch {
            settingsRepository.setLockNotificationEnabled(!settings.value.lockNotificationEnabled)
        }
    }

    fun ensureBackgroundLockEnabled() {
        if (!settings.value.backgroundLockEnabled) {
            viewModelScope.launch {
                settingsRepository.setBackgroundLockEnabled(true)
            }
        }
    }

    fun setPriorityApp(packageName: String?) {
        viewModelScope.launch {
            settingsRepository.setPriorityAppPackage(packageName)
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { settingsRepository.setThemeMode(mode) }
    }

    fun matchesFilter(constellation: Constellation, usedInFix: Boolean, filter: SatelliteFilter): Boolean {
        return when (filter) {
            SatelliteFilter.ALL -> true
            SatelliteFilter.USED -> usedInFix
            SatelliteFilter.GPS -> constellation == Constellation.GPS
            SatelliteFilter.GLONASS -> constellation == Constellation.GLONASS
            SatelliteFilter.GALILEO -> constellation == Constellation.GALILEO
            SatelliteFilter.BEIDOU -> constellation == Constellation.BEIDOU
            SatelliteFilter.QZSS -> constellation == Constellation.QZSS
            SatelliteFilter.SBAS -> constellation == Constellation.SBAS
        }
    }

    override fun onCleared() {
        super.onCleared()
        compassRepository.stopListening()
        if (!telemetryState.value.isBackgroundServiceActive) {
            gnssRepository.stopTracking()
        }
    }
}
