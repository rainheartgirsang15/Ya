package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.ConstellationBeidouColor
import com.example.ui.theme.ConstellationGalileoColor
import com.example.ui.theme.ConstellationGlonassColor
import com.example.ui.theme.ConstellationGpsColor
import com.example.ui.theme.ConstellationIrnssColor
import com.example.ui.theme.ConstellationQzssColor
import com.example.ui.theme.ConstellationSbasColor

enum class FixState {
    NO_PERMISSION,
    GPS_DISABLED,
    SEARCHING,
    FIX_2D,
    FIX_3D,
}

enum class GnssSignalGrade {
    ULTRA_STRONG,
    STRONG,
    MODERATE,
    WEAK,
}

enum class Constellation(
    val shortCode: String,
    val displayName: String,
    val color: Color,
) {
    GPS("G", "GPS", ConstellationGpsColor),
    GLONASS("R", "GLONASS", ConstellationGlonassColor),
    GALILEO("E", "Galileo", ConstellationGalileoColor),
    BEIDOU("C", "BeiDou", ConstellationBeidouColor),
    QZSS("J", "QZSS", ConstellationQzssColor),
    IRNSS("I", "NavIC", ConstellationIrnssColor),
    SBAS("S", "SBAS", ConstellationSbasColor),
    UNKNOWN("?", "Other", Color(0xFF64748B)),
}

data class SatelliteInfo(
    val svid: Int,
    val constellation: Constellation,
    val cn0DbHz: Float,
    val azimuthDeg: Float,
    val elevationDeg: Float,
    val usedInFix: Boolean,
    val hasAlmanac: Boolean,
    val hasEphemeris: Boolean,
    val carrierFreqMhz: Float?,
    val bandLabel: String?,
) {
    val key: String get() = "${constellation.shortCode}$svid"
}

data class LocationFix(
    val latitude: Double,
    val longitude: Double,
    val altitudeMeters: Double?,
    val mslAltitudeMeters: Double?,
    val accuracyMeters: Float?,
    val verticalAccuracyMeters: Float?,
    val speedMps: Float?,
    val speedAccuracyMps: Float?,
    val bearingDeg: Float?,
    val bearingAccuracyDeg: Float?,
    val provider: String,
    val timestampMillis: Long,
)

data class DopMetrics(
    val pdop: Float? = null,
    val hdop: Float? = null,
    val vdop: Float? = null,
    val fixMode: Int? = null, // 1 = No Fix, 2 = 2D, 3 = 3D
)

enum class NmeaType {
    GGA,
    GSA,
    RMC,
    GSV,
    OTHER,
}

data class NmeaEntry(
    val id: Long,
    val timestampMillis: Long,
    val sentence: String,
    val type: NmeaType,
)

data class AgpsFeedback(
    val message: String,
    val isSuccess: Boolean,
    val timestampMillis: Long,
)

enum class CoordFormat(val label: String) {
    DECIMAL_DEGREES("DD"),
    DMS("DMS"),
    DDM("DDM"),
}

enum class SpeedUnit(val label: String) {
    KMH("km/h"),
    MPH("mph"),
    KNOTS("kn"),
    MPS("m/s"),
}

enum class DistanceUnit(val label: String) {
    METRIC("m"),
    IMPERIAL("ft"),
}

enum class ThemeMode {
    SYSTEM,
    DARK,
    LIGHT,
}

enum class CompassAccuracy {
    HIGH,
    MEDIUM,
    LOW,
    UNRELIABLE,
}

data class CompassState(
    val isSupported: Boolean = false,
    val azimuthDeg: Float? = null,
    val pitchDeg: Float? = null,
    val rollDeg: Float? = null,
    val magneticFieldMicroTesla: Float? = null,
    val accuracy: CompassAccuracy = CompassAccuracy.UNRELIABLE,
)

data class PriorityAppInfo(
    val packageName: String,
    val label: String,
)

data class AppSettings(
    val coordFormat: CoordFormat = CoordFormat.DECIMAL_DEGREES,
    val speedUnit: SpeedUnit = SpeedUnit.KMH,
    val distanceUnit: DistanceUnit = DistanceUnit.METRIC,
    val keepScreenOn: Boolean = true,
    val backgroundLockEnabled: Boolean = true,
    val lockNotificationEnabled: Boolean = true,
    val priorityAppPackage: String? = null,
    val themeMode: ThemeMode = ThemeMode.DARK,
)

data class GnssTelemetryState(
    val hasLocationPermission: Boolean = false,
    val hasCoarseLocationPermission: Boolean = false,
    val isGpsProviderEnabled: Boolean = false,
    val isNetworkOnline: Boolean = false,
    val isGnssEngineRunning: Boolean = false,
    val isFullTrackingActive: Boolean = false,
    val isBackgroundServiceActive: Boolean = false,
    val isBatteryOptimizationIgnored: Boolean = false,
    val gnssHardwareModel: String? = null,
    val supportsDualFrequency: Boolean = false,
    val ttffMillis: Int? = null,
    val searchStartedAtMillis: Long = System.currentTimeMillis(),
    val locationFix: LocationFix? = null,
    val assistCoarseFix: LocationFix? = null,
    val maxSpeedMps: Float = 0f,
    val satellites: List<SatelliteInfo> = emptyList(),
    val dop: DopMetrics = DopMetrics(),
    val nmeaLogs: List<NmeaEntry> = emptyList(),
    val nmeaPaused: Boolean = false,
    val agpsFeedback: AgpsFeedback? = null,
) {
    val visibleSatelliteCount: Int get() = satellites.size
    val usedSatelliteCount: Int get() = satellites.count { it.usedInFix }
    val avgUsedCn0: Float?
        get() {
            val used = satellites.filter { it.usedInFix && it.cn0DbHz > 0f }
            if (used.isEmpty()) return null
            return used.map { it.cn0DbHz }.average().toFloat()
        }

    val signalGrade: GnssSignalGrade
        get() {
            val acc = locationFix?.accuracyMeters ?: 999f
            val used = usedSatelliteCount
            val cn0 = avgUsedCn0 ?: 0f
            return when {
                fixState == FixState.FIX_3D && acc <= 8f && used >= 8 && cn0 >= 28f -> GnssSignalGrade.ULTRA_STRONG
                (fixState == FixState.FIX_3D || fixState == FixState.FIX_2D) && acc <= 18f && used >= 5 -> GnssSignalGrade.STRONG
                fixState == FixState.FIX_3D || fixState == FixState.FIX_2D || used >= 3 -> GnssSignalGrade.MODERATE
                else -> GnssSignalGrade.WEAK
            }
        }

    val fixState: FixState
        get() = when {
            !hasLocationPermission -> FixState.NO_PERMISSION
            !isGpsProviderEnabled -> FixState.GPS_DISABLED
            locationFix != null -> {
                val hasAlt = locationFix.altitudeMeters != null || dop.fixMode == 3
                if (dop.fixMode == 2 && !hasAlt) FixState.FIX_2D else FixState.FIX_3D
            }
            dop.fixMode == 2 -> FixState.FIX_2D
            else -> FixState.SEARCHING
        }
}
