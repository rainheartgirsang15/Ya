package com.example.util

import com.example.model.Constellation
import com.example.model.CoordFormat
import com.example.model.DistanceUnit
import com.example.model.DopMetrics
import com.example.model.NmeaType
import com.example.model.SpeedUnit
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor

object Formatters {

    fun formatCoordinate(
        value: Double,
        isLatitude: Boolean,
        format: CoordFormat,
    ): String {
        val hemi = when {
            isLatitude && value >= 0 -> "N"
            isLatitude -> "S"
            value >= 0 -> "E"
            else -> "W"
        }
        val absVal = abs(value)
        return when (format) {
            CoordFormat.DECIMAL_DEGREES -> {
                String.format(Locale.US, "%.6f° %s", absVal, hemi)
            }
            CoordFormat.DMS -> {
                val deg = floor(absVal).toInt()
                val minFull = (absVal - deg) * 60.0
                val min = floor(minFull).toInt()
                val sec = (minFull - min) * 60.0
                String.format(Locale.US, "%d° %02d' %05.2f\" %s", deg, min, sec, hemi)
            }
            CoordFormat.DDM -> {
                val deg = floor(absVal).toInt()
                val min = (absVal - deg) * 60.0
                String.format(Locale.US, "%d° %06.3f' %s", deg, min, hemi)
            }
        }
    }

    fun formatAltitude(meters: Double?, unit: DistanceUnit): String {
        if (meters == null) return "—"
        return when (unit) {
            DistanceUnit.METRIC -> String.format(Locale.US, "%.1f m", meters)
            DistanceUnit.IMPERIAL -> String.format(Locale.US, "%.0f ft", meters * 3.28084)
        }
    }

    fun formatAccuracy(meters: Float?, unit: DistanceUnit): String {
        if (meters == null) return "—"
        return when (unit) {
            DistanceUnit.METRIC -> String.format(Locale.US, "±%.1f m", meters)
            DistanceUnit.IMPERIAL -> String.format(Locale.US, "±%.1f ft", meters * 3.28084f)
        }
    }

    fun convertSpeed(mps: Float, unit: SpeedUnit): Float = when (unit) {
        SpeedUnit.KMH -> mps * 3.6f
        SpeedUnit.MPH -> mps * 2.23694f
        SpeedUnit.KNOTS -> mps * 1.94384f
        SpeedUnit.MPS -> mps
    }

    fun formatSpeed(mps: Float?, unit: SpeedUnit): String {
        if (mps == null) return "—"
        val converted = convertSpeed(mps, unit)
        return String.format(Locale.US, "%.1f %s", converted, unit.label)
    }

    fun formatBearing(bearingDeg: Float?): String {
        if (bearingDeg == null) return "—"
        val normalized = ((bearingDeg % 360f) + 360f) % 360f
        val cardinals = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        val idx = (((normalized + 22.5f) % 360f) / 45f).toInt().coerceIn(0, 7)
        return String.format(Locale.US, "%.0f° %s", normalized, cardinals[idx])
    }

    fun formatTtff(ttffMillis: Int?): String {
        if (ttffMillis == null || ttffMillis <= 0) return "—"
        return if (ttffMillis < 1000) {
            "${ttffMillis} ms"
        } else {
            String.format(Locale.US, "%.1f s", ttffMillis / 1000.0)
        }
    }

    fun formatDurationSeconds(millis: Long): String {
        val clamped = millis.coerceAtLeast(0L)
        val totalSeconds = clamped / 1000
        val tenths = (clamped % 1000) / 100
        val mins = totalSeconds / 60
        val secs = totalSeconds % 60
        return if (mins > 0) {
            String.format(Locale.US, "%d:%02d.%d", mins, secs, tenths)
        } else {
            String.format(Locale.US, "%d.%ds", secs, tenths)
        }
    }

    fun formatTimestamp(millis: Long): String {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.US)
        return sdf.format(Date(millis))
    }

    fun classifyCarrierBand(constellation: Constellation, freqMhz: Float?): String? {
        if (freqMhz == null || freqMhz <= 0f) return null
        return when {
            freqMhz in 1559f..1610f -> when (constellation) {
                Constellation.GALILEO -> "E1"
                Constellation.BEIDOU -> "B1"
                Constellation.GLONASS -> "L1/G1"
                else -> "L1"
            }
            freqMhz in 1164f..1195f -> when (constellation) {
                Constellation.GALILEO -> "E5a"
                Constellation.BEIDOU -> "B2a"
                else -> "L5"
            }
            freqMhz in 1196f..1215f -> when (constellation) {
                Constellation.GALILEO -> "E5b"
                Constellation.BEIDOU -> "B2b"
                else -> "L2/E5b"
            }
            freqMhz in 1215f..1260f -> "L2"
            freqMhz in 1260f..1300f -> when (constellation) {
                Constellation.GALILEO -> "E6"
                Constellation.BEIDOU -> "B3"
                else -> "L6"
            }
            else -> String.format(Locale.US, "%.0fMHz", freqMhz)
        }
    }

    fun classifyNmeaType(sentence: String): NmeaType {
        val header = sentence.substringBefore(',').uppercase(Locale.US)
        return when {
            header.endsWith("GGA") -> NmeaType.GGA
            header.endsWith("GSA") -> NmeaType.GSA
            header.endsWith("RMC") -> NmeaType.RMC
            header.endsWith("GSV") -> NmeaType.GSV
            else -> NmeaType.OTHER
        }
    }

    fun parseNmeaGsa(sentence: String, current: DopMetrics): DopMetrics {
        // Format: $GNGSA,A,3,01,02,...,,,1.8,1.1,1.4*xx
        val body = sentence.substringBefore('*')
        val fields = body.split(',')
        if (fields.size < 18) return current
        val mode = fields.getOrNull(2)?.toIntOrNull()
        val pdop = fields.getOrNull(15)?.toFloatOrNull()
        val hdop = fields.getOrNull(16)?.toFloatOrNull()
        val vdop = fields.getOrNull(17)?.toFloatOrNull()
        return DopMetrics(
            pdop = pdop ?: current.pdop,
            hdop = hdop ?: current.hdop,
            vdop = vdop ?: current.vdop,
            fixMode = mode ?: current.fixMode,
        )
    }

    fun parseNmeaGgaMslAndHdop(sentence: String): Pair<Double?, Float?> {
        // Format: $GNGGA,time,lat,NS,lon,EW,quality,numSV,HDOP,alt,M,sep,M,...
        val body = sentence.substringBefore('*')
        val fields = body.split(',')
        if (fields.size < 10) return null to null
        val hdop = fields.getOrNull(8)?.toFloatOrNull()
        val altMsl = fields.getOrNull(9)?.toDoubleOrNull()
        return altMsl to hdop
    }
}
