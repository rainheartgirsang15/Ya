package com.example.data

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.example.model.CompassAccuracy
import com.example.model.CompassState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.sqrt

class CompassRepository(context: Context) {

    private val sensorManager =
        context.applicationContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    private val rotationVectorSensor: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val magnetometerSensor: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
    private val accelerometerSensor: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    val isCompassSupported: Boolean =
        magnetometerSensor != null && (rotationVectorSensor != null || accelerometerSensor != null)

    private val _state = MutableStateFlow(CompassState(isSupported = isCompassSupported))
    val state: StateFlow<CompassState> = _state.asStateFlow()

    private var isListening = false
    private var smoothedAzimuth: Float? = null

    private val gravityReading = FloatArray(3)
    private val magnetometerReading = FloatArray(3)
    private var hasGravity = false
    private var hasMagnetometer = false

    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)

    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            when (event.sensor.type) {
                Sensor.TYPE_ROTATION_VECTOR -> {
                    SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                    SensorManager.getOrientation(rotationMatrix, orientationAngles)
                    updateOrientationFromAngles(orientationAngles)
                }
                Sensor.TYPE_MAGNETIC_FIELD -> {
                    System.arraycopy(event.values, 0, magnetometerReading, 0, 3)
                    hasMagnetometer = true
                    val mx = event.values[0]
                    val my = event.values[1]
                    val mz = event.values[2]
                    val microTesla = sqrt(mx * mx + my * my + mz * mz)
                    _state.update { it.copy(magneticFieldMicroTesla = microTesla) }

                    if (rotationVectorSensor == null && hasGravity) {
                        if (SensorManager.getRotationMatrix(rotationMatrix, null, gravityReading, magnetometerReading)) {
                            SensorManager.getOrientation(rotationMatrix, orientationAngles)
                            updateOrientationFromAngles(orientationAngles)
                        }
                    }
                }
                Sensor.TYPE_ACCELEROMETER -> {
                    System.arraycopy(event.values, 0, gravityReading, 0, 3)
                    hasGravity = true
                    if (rotationVectorSensor == null && hasMagnetometer) {
                        if (SensorManager.getRotationMatrix(rotationMatrix, null, gravityReading, magnetometerReading)) {
                            SensorManager.getOrientation(rotationMatrix, orientationAngles)
                            updateOrientationFromAngles(orientationAngles)
                        }
                    }
                }
            }
        }

        override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {
            if (sensor.type == Sensor.TYPE_MAGNETIC_FIELD ||
                (sensor.type == Sensor.TYPE_ROTATION_VECTOR && magnetometerSensor == null)
            ) {
                val mapped = when (accuracy) {
                    SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> CompassAccuracy.HIGH
                    SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> CompassAccuracy.MEDIUM
                    SensorManager.SENSOR_STATUS_ACCURACY_LOW -> CompassAccuracy.LOW
                    else -> CompassAccuracy.UNRELIABLE
                }
                _state.update { it.copy(accuracy = mapped) }
            }
        }
    }

    fun startListening() {
        if (!isCompassSupported || isListening) return
        rotationVectorSensor?.let {
            sensorManager.registerListener(sensorListener, it, SensorManager.SENSOR_DELAY_UI)
        }
        magnetometerSensor?.let {
            sensorManager.registerListener(sensorListener, it, SensorManager.SENSOR_DELAY_UI)
        }
        if (rotationVectorSensor == null) {
            accelerometerSensor?.let {
                sensorManager.registerListener(sensorListener, it, SensorManager.SENSOR_DELAY_UI)
            }
        }
        isListening = true
    }

    fun stopListening() {
        if (!isListening) return
        sensorManager.unregisterListener(sensorListener)
        isListening = false
    }

    fun resampleCalibration() {
        if (!isCompassSupported) return
        stopListening()
        smoothedAzimuth = null
        hasGravity = false
        hasMagnetometer = false
        startListening()
    }

    private fun updateOrientationFromAngles(angles: FloatArray) {
        val rawAzimuth = ((Math.toDegrees(angles[0].toDouble()) + 360.0) % 360.0).toFloat()
        val smoothed = smoothCircularAngle(smoothedAzimuth, rawAzimuth, alpha = 0.22f)
        smoothedAzimuth = smoothed

        val pitch = Math.toDegrees(angles[1].toDouble()).toFloat()
        val roll = Math.toDegrees(angles[2].toDouble()).toFloat()

        _state.update {
            it.copy(
                azimuthDeg = smoothed,
                pitchDeg = pitch,
                rollDeg = roll,
            )
        }
    }

    private fun smoothCircularAngle(prev: Float?, next: Float, alpha: Float): Float {
        if (prev == null) return next
        val delta = ((next - prev + 540f) % 360f) - 180f
        return ((prev + alpha * delta) + 360f) % 360f
    }
}
