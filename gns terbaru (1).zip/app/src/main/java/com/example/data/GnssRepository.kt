package com.example.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.GnssMeasurementRequest
import android.location.GnssMeasurementsEvent
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.location.LocationRequest
import android.location.OnNmeaMessageListener
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.example.model.AgpsFeedback
import com.example.model.Constellation
import com.example.model.DopMetrics
import com.example.model.GnssTelemetryState
import com.example.model.LocationFix
import com.example.model.NmeaEntry
import com.example.model.NmeaType
import com.example.model.SatelliteInfo
import com.example.util.Formatters
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.Granularity
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest as GmsLocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.atomic.AtomicLong

class GnssRepository(context: Context) {

    private val appContext = context.applicationContext
    private val locationManager =
        appContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val connectivityManager =
        appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(appContext)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val nmeaCounter = AtomicLong(0L)
    private var latestMslAltitude: Double? = null
    private var lastRawGpsFixMillis = 0L
    private var lastAutoAgpsMillis = 0L
    private var lastStallRecoveryMillis = 0L
    private var previousFixLocation: Location? = null
    private var previousFixTimeMillis = 0L
    private var isTracking = false
    private var isFusedTracking = false
    private var isAssistTracking = false
    private var isFullTrackingRegistered = false
    private var receiverRegistered = false

    private val _state = MutableStateFlow(
        GnssTelemetryState(
            hasLocationPermission = checkFineLocationPermission(),
            hasCoarseLocationPermission = checkCoarseLocationPermission(),
            isGpsProviderEnabled = checkGpsProviderEnabled(),
            isNetworkOnline = checkNetworkOnline(),
            isBatteryOptimizationIgnored = PriorityAppHelper.isIgnoringBatteryOptimizations(appContext),
            gnssHardwareModel = readHardwareModel(),
        )
    )
    val state: StateFlow<GnssTelemetryState> = _state.asStateFlow()

    private val providerChangedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshEnvironmentStatus()
        }
    }

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            val now = System.currentTimeMillis()
            lastRawGpsFixMillis = now
            applyLocationUpdate(location, now, isRawGps = true)
        }

        @Deprecated("Deprecated in Android API 29")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

        override fun onProviderEnabled(provider: String) {
            refreshEnvironmentStatus()
        }

        override fun onProviderDisabled(provider: String) {
            refreshEnvironmentStatus()
        }
    }

    private val fusedLocationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.lastLocation?.let { onFusedLocation(it) }
        }
    }

    private val gnssMeasurementsCallback = object : GnssMeasurementsEvent.Callback() {}

    fun onFusedLocation(location: Location) {
        val now = System.currentTimeMillis()
        // Prefer fresh raw GPS_PROVIDER fixes if received within the last 4 seconds
        if (now - lastRawGpsFixMillis >= 4000L) {
            applyLocationUpdate(location, now, isRawGps = false)
        }
    }

    private fun applyLocationUpdate(
        location: Location,
        nowMillis: Long,
        isRawGps: Boolean,
    ) {
        val currentFix = _state.value.locationFix
        val incomingAcc = if (location.hasAccuracy()) location.accuracy else 999f
        // Anti-jump filter: protect a fresh, tight 3D fix from coarse cell/WiFi fallback jumps
        if (currentFix != null) {
            val ageMs = nowMillis - currentFix.timestampMillis
            val currentAcc = currentFix.accuracyMeters ?: 999f
            if (ageMs in 0..12_000L && currentAcc <= 20f && incomingAcc > 65f) {
                return
            }
            if (!isRawGps && ageMs in 0..15_000L && currentAcc <= 15f && incomingAcc > 40f) {
                return
            }
        }

        val computedSpeedMps = computeSpeedMps(location, nowMillis)
        previousFixLocation = location
        previousFixTimeMillis = nowMillis

        val fix = location.toLocationFix(
            mslOverride = latestMslAltitude,
            speedOverrideMps = computedSpeedMps,
        )
        _state.update { current ->
            val speed = fix.speedMps ?: 0f
            current.copy(
                locationFix = fix,
                maxSpeedMps = maxOf(current.maxSpeedMps, speed),
            )
        }
    }

    private fun computeSpeedMps(location: Location, nowMillis: Long): Float? {
        if (location.hasSpeed()) {
            return location.speed.coerceAtLeast(0f)
        }
        val prev = previousFixLocation ?: return null
        val dtMillis = nowMillis - previousFixTimeMillis
        if (dtMillis < 250L || dtMillis > 15_000L) return null
        val distance = prev.distanceTo(location)
        val dtSec = dtMillis / 1000f
        val speed = distance / dtSec
        // Suppress stationary GPS drift when accuracy circle is larger than displacement
        val acc = if (location.hasAccuracy()) location.accuracy else 25f
        return if (distance < acc * 0.5f && speed < 0.8f) 0f else speed
    }

    private val assistLocationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            val coarse = location.toLocationFix(mslOverride = null)
            _state.update { it.copy(assistCoarseFix = coarse) }
        }

        @Deprecated("Deprecated in Android API 29")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

        override fun onProviderEnabled(provider: String) {}

        override fun onProviderDisabled(provider: String) {}
    }

    private val gnssStatusCallback = object : GnssStatus.Callback() {
        override fun onStarted() {
            _state.update {
                it.copy(
                    isGnssEngineRunning = true,
                    searchStartedAtMillis = System.currentTimeMillis(),
                )
            }
        }

        override fun onStopped() {
            _state.update { it.copy(isGnssEngineRunning = false) }
        }

        override fun onFirstFix(ttffMillis: Int) {
            _state.update { it.copy(ttffMillis = ttffMillis) }
        }

        override fun onSatelliteStatusChanged(status: GnssStatus) {
            val count = status.satelliteCount
            val list = ArrayList<SatelliteInfo>(count)
            val bandsSeen = HashSet<String>()

            for (i in 0 until count) {
                val constellation = mapConstellation(status.getConstellationType(i))
                val freqMhz = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && status.hasCarrierFrequencyHz(i)) {
                    status.getCarrierFrequencyHz(i) / 1_000_000f
                } else null
                val band = Formatters.classifyCarrierBand(constellation, freqMhz)
                if (band != null && (band.contains("5") || band.contains("2"))) {
                    bandsSeen.add(band)
                }
                list.add(
                    SatelliteInfo(
                        svid = status.getSvid(i),
                        constellation = constellation,
                        cn0DbHz = status.getCn0DbHz(i),
                        azimuthDeg = status.getAzimuthDegrees(i),
                        elevationDeg = status.getElevationDegrees(i),
                        usedInFix = status.usedInFix(i),
                        hasAlmanac = status.hasAlmanacData(i),
                        hasEphemeris = status.hasEphemerisData(i),
                        carrierFreqMhz = freqMhz,
                        bandLabel = band,
                    )
                )
            }

            val sorted = list.sortedWith(
                compareByDescending<SatelliteInfo> { it.usedInFix }
                    .thenByDescending { it.cn0DbHz }
                    .thenBy { it.constellation.ordinal }
                    .thenBy { it.svid }
            )

            _state.update { current ->
                current.copy(
                    satellites = sorted,
                    supportsDualFrequency = current.supportsDualFrequency || bandsSeen.isNotEmpty(),
                )
            }
        }
    }

    private val nmeaListener = OnNmeaMessageListener { message, timestamp ->
        val trimmed = message.trim()
        if (trimmed.isEmpty()) return@OnNmeaMessageListener
        val type = Formatters.classifyNmeaType(trimmed)

        if (type == NmeaType.GGA) {
            val (msl, hdop) = Formatters.parseNmeaGgaMslAndHdop(trimmed)
            if (msl != null) {
                latestMslAltitude = msl
            }
            if (hdop != null) {
                _state.update { current ->
                    current.copy(
                        dop = current.dop.copy(hdop = hdop),
                        locationFix = current.locationFix?.copy(
                            mslAltitudeMeters = msl ?: current.locationFix.mslAltitudeMeters,
                        ),
                    )
                }
            }
        } else if (type == NmeaType.GSA) {
            _state.update { current ->
                current.copy(dop = Formatters.parseNmeaGsa(trimmed, current.dop))
            }
        }

        _state.update { current ->
            if (current.nmeaPaused) {
                current
            } else {
                val entry = NmeaEntry(
                    id = nmeaCounter.incrementAndGet(),
                    timestampMillis = if (timestamp > 1_000_000_000_000L) timestamp else System.currentTimeMillis(),
                    sentence = trimmed,
                    type = type,
                )
                val updated = (listOf(entry) + current.nmeaLogs).take(MAX_NMEA_LOG_ENTRIES)
                current.copy(nmeaLogs = updated)
            }
        }
    }

    fun startTracking() {
        registerProviderReceiver()
        refreshEnvironmentStatus()

        if (!checkFineLocationPermission()) {
            stopGnssListeners()
            return
        }
        if (isTracking) return

        startGnssListeners()
    }

    fun stopTracking() {
        stopGnssListeners()
        unregisterProviderReceiver()
    }

    fun setBackgroundServiceActive(active: Boolean) {
        _state.update { it.copy(isBackgroundServiceActive = active) }
    }

    fun refreshEnvironmentStatus() {
        val hasPerm = checkFineLocationPermission()
        val hasCoarse = checkCoarseLocationPermission()
        val gpsEnabled = checkGpsProviderEnabled()
        val online = checkNetworkOnline()
        val batteryIgnored = PriorityAppHelper.isIgnoringBatteryOptimizations(appContext)
        _state.update {
            it.copy(
                hasLocationPermission = hasPerm,
                hasCoarseLocationPermission = hasCoarse,
                isGpsProviderEnabled = gpsEnabled,
                isNetworkOnline = online,
                isBatteryOptimizationIgnored = batteryIgnored,
                gnssHardwareModel = it.gnssHardwareModel ?: readHardwareModel(),
            )
        }
        if (hasPerm && gpsEnabled && !isTracking) {
            startGnssListeners()
        } else if ((!hasPerm || !gpsEnabled) && isTracking) {
            stopGnssListeners()
        }
    }

    @SuppressLint("MissingPermission")
    fun boostAgpsFix() {
        if (!checkFineLocationPermission()) return
        val timeOk = runCatching {
            locationManager.sendExtraCommand(LocationManager.GPS_PROVIDER, "force_time_injection", null)
        }.getOrDefault(false)
        val xtraOk = runCatching {
            locationManager.sendExtraCommand(LocationManager.GPS_PROVIDER, "force_xtra_injection", null)
        }.getOrDefault(false)

        // Do NOT tear down an active GNSS session (it wipes ephemeris download in progress).
        // Only start listeners if not already running, and nudge Fused + coarse network assist.
        if (!isTracking) {
            startGnssListeners()
        } else {
            if (!isFusedTracking) startFusedLocationUpdates()
            if (!isAssistTracking) startNetworkAssistListener()
        }

        runCatching {
            fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                .addOnSuccessListener { loc ->
                    if (loc != null) {
                        val fix = loc.toLocationFix(mslOverride = latestMslAltitude)
                        _state.update { current ->
                            if (current.locationFix == null) current.copy(locationFix = fix) else current
                        }
                    }
                }
        }

        val msg = when {
            xtraOk && timeOk -> "A-GPS XTRA & NTP time injected into live GNSS session."
            xtraOk || timeOk -> "A-GPS assist injected; Fused + GNSS lock session active."
            else -> "Fused + GNSS high-accuracy session active; A-GPS assist requested."
        }
        _state.update {
            it.copy(
                agpsFeedback = AgpsFeedback(
                    message = msg,
                    isSuccess = true,
                    timestampMillis = System.currentTimeMillis(),
                )
            )
        }
    }

    @SuppressLint("MissingPermission")
    fun coldResetGnss() {
        if (!checkFineLocationPermission()) return
        val cleared = runCatching {
            locationManager.sendExtraCommand(LocationManager.GPS_PROVIDER, "delete_aiding_data", null)
        }.getOrDefault(false)

        latestMslAltitude = null
        previousFixLocation = null
        previousFixTimeMillis = 0L
        stopGnssListeners()
        _state.update {
            it.copy(
                locationFix = null,
                ttffMillis = null,
                maxSpeedMps = 0f,
                dop = DopMetrics(),
                satellites = emptyList(),
                searchStartedAtMillis = System.currentTimeMillis(),
                agpsFeedback = AgpsFeedback(
                    message = if (cleared) {
                        "Aiding data cleared. Cold-start GNSS acquisition restarted."
                    } else {
                        "Cold-start reset requested; GNSS tracking restarted."
                    },
                    isSuccess = true,
                    timestampMillis = System.currentTimeMillis(),
                ),
            )
        }
        startGnssListeners()
    }

    fun resetMaxSpeed() {
        _state.update { current ->
            current.copy(maxSpeedMps = current.locationFix?.speedMps ?: 0f)
        }
    }

    fun toggleNmeaPaused() {
        _state.update { it.copy(nmeaPaused = !it.nmeaPaused) }
    }

    fun clearNmeaLogs() {
        _state.update { it.copy(nmeaLogs = emptyList()) }
    }

    fun clearAgpsFeedback() {
        _state.update { it.copy(agpsFeedback = null) }
    }

    @SuppressLint("MissingPermission")
    fun recoverStalledLockIfNeeded(staleThresholdMs: Long = 15_000L) {
        if (!checkFineLocationPermission() || !checkGpsProviderEnabled()) return
        val now = System.currentTimeMillis()
        val timeSinceRawGps = now - lastRawGpsFixMillis
        if (lastRawGpsFixMillis > 0L && timeSinceRawGps < staleThresholdMs) return
        if (now - lastStallRecoveryMillis < 45_000L) return
        lastStallRecoveryMillis = now

        if (checkNetworkOnline() && now - lastAutoAgpsMillis >= 90_000L) {
            injectAgpsQuietly()
        }
        runCatching {
            fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                .addOnSuccessListener { loc ->
                    if (loc != null) {
                        onFusedLocation(loc)
                    }
                }
        }
        // Re-bind GPS listener cleanly if it stopped delivering updates
        if (isTracking) {
            runCatching { locationManager.removeUpdates(locationListener) }
            isTracking = false
            startGnssListeners()
        }
    }

    @SuppressLint("MissingPermission")
    private fun injectAgpsQuietly() {
        if (!checkFineLocationPermission()) return
        lastAutoAgpsMillis = System.currentTimeMillis()
        runCatching {
            locationManager.sendExtraCommand(LocationManager.GPS_PROVIDER, "force_time_injection", null)
        }
        runCatching {
            locationManager.sendExtraCommand(LocationManager.GPS_PROVIDER, "force_xtra_injection", null)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startGnssListeners() {
        if (!checkFineLocationPermission() || !checkGpsProviderEnabled()) return
        if (isTracking) return

        val result = runCatching {
            val hasGps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                locationManager.hasProvider(LocationManager.GPS_PROVIDER)
            } else {
                locationManager.allProviders.contains(LocationManager.GPS_PROVIDER)
            }

            if (hasGps) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val request = LocationRequest.Builder(1000L)
                        .setQuality(LocationRequest.QUALITY_HIGH_ACCURACY)
                        .setMinUpdateIntervalMillis(500L)
                        .setMinUpdateDistanceMeters(0f)
                        .setMaxUpdateDelayMillis(0L)
                        .build()
                    locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        request,
                        ContextCompat.getMainExecutor(appContext),
                        locationListener,
                    )
                } else {
                    locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER,
                        1000L,
                        0f,
                        locationListener,
                        Looper.getMainLooper(),
                    )
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                locationManager.registerGnssStatusCallback(
                    ContextCompat.getMainExecutor(appContext),
                    gnssStatusCallback,
                )
                locationManager.addNmeaListener(
                    ContextCompat.getMainExecutor(appContext),
                    nmeaListener,
                )
            } else {
                @Suppress("DEPRECATION")
                locationManager.registerGnssStatusCallback(gnssStatusCallback, mainHandler)
                @Suppress("DEPRECATION")
                locationManager.addNmeaListener(nmeaListener, mainHandler)
            }

            // Disable GNSS chipset duty-cycling on Android 12+ (Full-Tracking continuous lock)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !isFullTrackingRegistered) {
                runCatching {
                    val measReq = GnssMeasurementRequest.Builder()
                        .setFullTracking(true)
                        .build()
                    isFullTrackingRegistered = locationManager.registerGnssMeasurementsCallback(
                        measReq,
                        ContextCompat.getMainExecutor(appContext),
                        gnssMeasurementsCallback,
                    )
                }
            }

            // Auto-inject NTP & XTRA ephemeris on start when internet is available
            if (checkNetworkOnline() && System.currentTimeMillis() - lastAutoAgpsMillis >= 120_000L) {
                injectAgpsQuietly()
            }

            startFusedLocationUpdates()
            startNetworkAssistListener()

            isTracking = true
            _state.update {
                it.copy(
                    isGnssEngineRunning = true,
                    isFullTrackingActive = isFullTrackingRegistered,
                    searchStartedAtMillis = System.currentTimeMillis(),
                )
            }
        }

        result.onFailure { error ->
            _state.update {
                it.copy(
                    agpsFeedback = AgpsFeedback(
                        message = "GNSS start error: ${error.localizedMessage ?: error.javaClass.simpleName}",
                        isSuccess = false,
                        timestampMillis = System.currentTimeMillis(),
                    )
                )
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startFusedLocationUpdates() {
        if (isFusedTracking) return
        runCatching {
            val gmsRequest = GmsLocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
                .setMinUpdateIntervalMillis(500L)
                .setMinUpdateDistanceMeters(0f)
                .setMaxUpdateDelayMillis(0L)
                .setGranularity(Granularity.GRANULARITY_FINE)
                .setWaitForAccurateLocation(false)
                .build()
            fusedLocationClient.requestLocationUpdates(
                gmsRequest,
                fusedLocationCallback,
                Looper.getMainLooper(),
            )
            isFusedTracking = true
        }
    }

    @SuppressLint("MissingPermission")
    private fun startNetworkAssistListener() {
        if (isAssistTracking) return
        val hasNetworkProvider = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            locationManager.hasProvider(LocationManager.NETWORK_PROVIDER)
        } else {
            locationManager.allProviders.contains(LocationManager.NETWORK_PROVIDER)
        }
        if (!hasNetworkProvider) return

        runCatching {
            locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)?.let { lastNet ->
                _state.update { it.copy(assistCoarseFix = lastNet.toLocationFix(null)) }
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    5000L,
                    10f,
                    assistLocationListener,
                    Looper.getMainLooper(),
                )
                isAssistTracking = true
            }
        }
    }

    private fun stopGnssListeners() {
        if (!isTracking && !isFusedTracking && !isAssistTracking && !isFullTrackingRegistered) return
        runCatching { locationManager.removeUpdates(locationListener) }
        runCatching { fusedLocationClient.removeLocationUpdates(fusedLocationCallback) }
        runCatching { locationManager.removeUpdates(assistLocationListener) }
        runCatching { locationManager.unregisterGnssStatusCallback(gnssStatusCallback) }
        runCatching { locationManager.removeNmeaListener(nmeaListener) }
        if (isFullTrackingRegistered) {
            runCatching { locationManager.unregisterGnssMeasurementsCallback(gnssMeasurementsCallback) }
            isFullTrackingRegistered = false
        }
        isTracking = false
        isFusedTracking = false
        isAssistTracking = false
        _state.update {
            it.copy(
                isGnssEngineRunning = false,
                isFullTrackingActive = false,
            )
        }
    }

    private fun registerProviderReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION)
        ContextCompat.registerReceiver(
            appContext,
            providerChangedReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        receiverRegistered = true
    }

    private fun unregisterProviderReceiver() {
        if (!receiverRegistered) return
        runCatching { appContext.unregisterReceiver(providerChangedReceiver) }
        receiverRegistered = false
    }

    private fun checkFineLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.ACCESS_FINE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun checkCoarseLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun checkGpsProviderEnabled(): Boolean {
        return runCatching {
            locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        }.getOrDefault(false)
    }

    private fun checkNetworkOnline(): Boolean {
        val network = connectivityManager.activeNetwork ?: return false
        val caps = connectivityManager.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun readHardwareModel(): String? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            runCatching { locationManager.gnssHardwareModelName?.takeIf { it.isNotBlank() } }.getOrNull()
        } else null
    }

    private fun Location.toLocationFix(
        mslOverride: Double?,
        speedOverrideMps: Float? = null,
    ): LocationFix {
        val resolvedSpeed = speedOverrideMps ?: if (hasSpeed()) speed else null
        return LocationFix(
            latitude = latitude,
            longitude = longitude,
            altitudeMeters = if (hasAltitude()) altitude else null,
            mslAltitudeMeters = mslOverride,
            accuracyMeters = if (hasAccuracy()) accuracy else null,
            verticalAccuracyMeters = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && hasVerticalAccuracy()) {
                verticalAccuracyMeters
            } else null,
            speedMps = resolvedSpeed,
            speedAccuracyMps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && hasSpeedAccuracy()) {
                speedAccuracyMetersPerSecond
            } else null,
            bearingDeg = if (hasBearing()) bearing else null,
            bearingAccuracyDeg = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && hasBearingAccuracy()) {
                bearingAccuracyDegrees
            } else null,
            provider = provider ?: LocationManager.GPS_PROVIDER,
            timestampMillis = System.currentTimeMillis(),
        )
    }

    private fun mapConstellation(type: Int): Constellation {
        return when {
            type == GnssStatus.CONSTELLATION_GPS -> Constellation.GPS
            type == GnssStatus.CONSTELLATION_GLONASS -> Constellation.GLONASS
            type == GnssStatus.CONSTELLATION_GALILEO -> Constellation.GALILEO
            type == GnssStatus.CONSTELLATION_BEIDOU -> Constellation.BEIDOU
            type == GnssStatus.CONSTELLATION_QZSS -> Constellation.QZSS
            type == GnssStatus.CONSTELLATION_SBAS -> Constellation.SBAS
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && type == GnssStatus.CONSTELLATION_IRNSS ->
                Constellation.IRNSS
            else -> Constellation.UNKNOWN
        }
    }

    companion object {
        private const val MAX_NMEA_LOG_ENTRIES = 300
    }
}
