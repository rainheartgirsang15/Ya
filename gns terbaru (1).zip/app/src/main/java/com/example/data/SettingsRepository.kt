package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppSettings
import com.example.model.CoordFormat
import com.example.model.DistanceUnit
import com.example.model.SpeedUnit
import com.example.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "gnss_fix_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val COORD_FORMAT = stringPreferencesKey("coord_format")
        val SPEED_UNIT = stringPreferencesKey("speed_unit")
        val DISTANCE_UNIT = stringPreferencesKey("distance_unit")
        val KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
        val BACKGROUND_LOCK_ENABLED = booleanPreferencesKey("background_lock_enabled")
        val LOCK_NOTIFICATION_ENABLED = booleanPreferencesKey("lock_notification_enabled")
        val PRIORITY_APP_PACKAGE = stringPreferencesKey("priority_app_package")
        val THEME_MODE = stringPreferencesKey("theme_mode")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            coordFormat = prefs[Keys.COORD_FORMAT]?.let { runCatching { CoordFormat.valueOf(it) }.getOrNull() }
                ?: CoordFormat.DECIMAL_DEGREES,
            speedUnit = prefs[Keys.SPEED_UNIT]?.let { runCatching { SpeedUnit.valueOf(it) }.getOrNull() }
                ?: SpeedUnit.KMH,
            distanceUnit = prefs[Keys.DISTANCE_UNIT]?.let { runCatching { DistanceUnit.valueOf(it) }.getOrNull() }
                ?: DistanceUnit.METRIC,
            keepScreenOn = prefs[Keys.KEEP_SCREEN_ON] ?: true,
            backgroundLockEnabled = prefs[Keys.BACKGROUND_LOCK_ENABLED] ?: true,
            lockNotificationEnabled = prefs[Keys.LOCK_NOTIFICATION_ENABLED] ?: true,
            priorityAppPackage = prefs[Keys.PRIORITY_APP_PACKAGE]?.takeIf { it.isNotBlank() },
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
                ?: ThemeMode.DARK,
        )
    }

    suspend fun setCoordFormat(format: CoordFormat) {
        context.dataStore.edit { it[Keys.COORD_FORMAT] = format.name }
    }

    suspend fun setSpeedUnit(unit: SpeedUnit) {
        context.dataStore.edit { it[Keys.SPEED_UNIT] = unit.name }
    }

    suspend fun setDistanceUnit(unit: DistanceUnit) {
        context.dataStore.edit { it[Keys.DISTANCE_UNIT] = unit.name }
    }

    suspend fun setKeepScreenOn(enabled: Boolean) {
        context.dataStore.edit { it[Keys.KEEP_SCREEN_ON] = enabled }
    }

    suspend fun setBackgroundLockEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BACKGROUND_LOCK_ENABLED] = enabled }
    }

    suspend fun setLockNotificationEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.LOCK_NOTIFICATION_ENABLED] = enabled }
    }

    suspend fun setPriorityAppPackage(packageName: String?) {
        context.dataStore.edit { prefs ->
            if (packageName.isNullOrBlank()) {
                prefs.remove(Keys.PRIORITY_APP_PACKAGE)
            } else {
                prefs[Keys.PRIORITY_APP_PACKAGE] = packageName
            }
        }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }
}
