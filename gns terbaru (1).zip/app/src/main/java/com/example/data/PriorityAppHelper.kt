package com.example.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import com.example.model.PriorityAppInfo

enum class DriverPlatform(
    val displayName: String,
    val candidatePackages: List<String>,
) {
    GOJEK(
        displayName = "Gojek Driver",
        candidatePackages = listOf(
            "com.gojek.partner",
            "com.gojek.driver.bike",
            "com.gojek.driver.car",
            "com.gojek.driver",
            "com.gojek.driver.kilat",
        ),
    ),
    GRAB(
        displayName = "Grab Driver",
        candidatePackages = listOf(
            "com.grabtaxi.driver2",
            "com.grabtaxi.driver",
        ),
    ),
    SHOPEE(
        displayName = "Shopee Driver",
        candidatePackages = listOf(
            "com.shopee.foody.driver.id",
            "com.shopee.food.driver.id",
            "com.shopee.fms",
        ),
    ),
    MAXIM(
        displayName = "Maxim Driver",
        candidatePackages = listOf(
            "com.taxsee.driver",
        ),
    ),
    INDRIVE(
        displayName = "inDrive",
        candidatePackages = listOf(
            "sinet.startup.inDriver",
        ),
    ),
}

data class DriverPresetMatch(
    val platform: DriverPlatform,
    val installedApp: PriorityAppInfo?,
)

object PriorityAppHelper {

    private val KNOWN_PRIORITY_PACKAGES = listOf(
        "com.gojek.partner",
        "com.gojek.driver",
        "com.gojek.driver.bike",
        "com.gojek.driver.car",
        "com.gojek.driver.kilat",
        "com.grabtaxi.driver2",
        "com.grabtaxi.driver",
        "com.shopee.foody.driver.id",
        "com.shopee.food.driver.id",
        "com.shopee.fms",
        "com.taxsee.driver",
        "sinet.startup.inDriver",
        "com.google.android.apps.maps",
        "com.waze",
        "com.grabtaxi.passenger",
        "com.gojek.app",
        "com.taxsee.taxsee",
        "net.osmand",
        "net.osmand.plus",
        "app.organicmaps",
        "com.strava",
    )

    fun queryInstalledPriorityApps(context: Context): List<PriorityAppInfo> {
        val pm = context.packageManager
        val selfPkg = context.packageName
        val discovered = linkedMapOf<String, PriorityAppInfo>()

        // 1. Check known navigation & driver apps declared in <queries>
        for (pkg in KNOWN_PRIORITY_PACKAGES) {
            if (pkg == selfPkg) continue
            pm.getLaunchIntentForPackage(pkg) ?: continue
            val label = resolveAppLabel(pm, pkg) ?: pkg
            discovered[pkg] = PriorityAppInfo(packageName = pkg, label = label)
        }

        // 2. Query any other map/geo handler declared via <intent> geo scheme in <queries>
        val geoIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0"))
        val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(geoIntent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(geoIntent, PackageManager.MATCH_DEFAULT_ONLY)
        }

        for (info in resolveInfos) {
            val pkg = info.activityInfo?.packageName ?: continue
            if (pkg == selfPkg || discovered.containsKey(pkg)) continue
            if (pm.getLaunchIntentForPackage(pkg) == null) continue
            val label = info.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
            discovered[pkg] = PriorityAppInfo(packageName = pkg, label = label)
        }

        return discovered.values.sortedBy { it.label.lowercase() }
    }

    fun resolveAppLabel(pm: PackageManager, packageName: String): String? {
        return runCatching {
            val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
            pm.getApplicationLabel(appInfo).toString().takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    fun buildLaunchIntent(context: Context, packageName: String?, lat: Double?, lon: Double?): Intent {
        if (!packageName.isNullOrBlank()) {
            val appIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (appIntent != null) {
                appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                return appIntent
            }
        }
        val uri = if (lat != null && lon != null) {
            Uri.parse("geo:$lat,$lon?q=$lat,$lon(GNSS+Fix)")
        } else {
            Uri.parse("geo:0,0")
        }
        return Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return runCatching { pm.isIgnoringBatteryOptimizations(context.packageName) }.getOrDefault(false)
    }

    fun openBatteryOptimizationSettings(context: Context) {
        val batterySettings = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val launched = runCatching {
            context.startActivity(batterySettings)
            true
        }.getOrDefault(false)

        if (!launched) {
            val appDetails = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", context.packageName, null),
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(appDetails) }
        }
    }

    fun matchDriverPlatforms(apps: List<PriorityAppInfo>): List<DriverPresetMatch> {
        return DriverPlatform.entries.map { platform ->
            val matched = platform.candidatePackages.firstNotNullOfOrNull { pkg ->
                apps.find { it.packageName == pkg }
            }
            DriverPresetMatch(platform = platform, installedApp = matched)
        }
    }

    fun findGojekDriverApp(apps: List<PriorityAppInfo>): PriorityAppInfo? {
        return matchDriverPlatforms(apps)
            .firstOrNull { it.platform == DriverPlatform.GOJEK }
            ?.installedApp
    }
}
