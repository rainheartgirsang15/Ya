package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.GpsFixed
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material.icons.outlined.SignalCellularAlt
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.GpsFixed
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.FixState
import com.example.service.GnssLockService
import com.example.ui.components.CompassScreen
import com.example.ui.components.NmeaLogScreen
import com.example.ui.components.SettingsSheet
import com.example.ui.components.SignalsScreen
import com.example.ui.components.SkyplotScreen
import com.example.ui.screens.FixDashboardScreen
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.AmberSearch
import com.example.ui.theme.GnssFixTheme
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.TabularMonoStyle
import com.example.viewmodel.GnssTab
import com.example.viewmodel.GnssViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: GnssViewModel = viewModel()
            val telemetry by viewModel.telemetryState.collectAsStateWithLifecycle()
            val compassState by viewModel.compassState.collectAsStateWithLifecycle()
            val skyplotCompassAlign by viewModel.skyplotCompassAlign.collectAsStateWithLifecycle()
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
            val satelliteFilter by viewModel.satelliteFilter.collectAsStateWithLifecycle()
            val nmeaFilter by viewModel.nmeaFilter.collectAsStateWithLifecycle()
            val selectedSatKey by viewModel.selectedSatelliteKey.collectAsStateWithLifecycle()
            val nowMillis by viewModel.nowMillis.collectAsStateWithLifecycle()
            val installedPriorityApps by viewModel.installedPriorityApps.collectAsStateWithLifecycle()

            LaunchedEffect(settings.keepScreenOn) {
                if (settings.keepScreenOn) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            var permissionPermanentlyDenied by remember { mutableStateOf(false) }
            var hasNotificationPermission by remember {
                mutableStateOf(
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        ContextCompat.checkSelfPermission(
                            this@MainActivity,
                            Manifest.permission.POST_NOTIFICATIONS,
                        ) == PackageManager.PERMISSION_GRANTED
                    } else {
                        true
                    }
                )
            }

            val notificationPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission(),
                onResult = { granted ->
                    hasNotificationPermission = granted
                    if (granted && !settings.lockNotificationEnabled) {
                        viewModel.toggleLockNotification()
                    }
                },
            )

            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions(),
                onResult = { permissions ->
                    val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
                    permissionPermanentlyDenied = if (!fineGranted) {
                        !ActivityCompat.shouldShowRequestPermissionRationale(
                            this@MainActivity,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                        )
                    } else {
                        false
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        permissions.containsKey(Manifest.permission.POST_NOTIFICATIONS)
                    ) {
                        hasNotificationPermission = permissions[Manifest.permission.POST_NOTIFICATIONS] == true
                    }
                    viewModel.onPermissionResult()
                    viewModel.startTracking()
                },
            )

            LaunchedEffect(telemetry.hasLocationPermission) {
                if (telemetry.hasLocationPermission) {
                    permissionPermanentlyDenied = false
                }
            }

            LaunchedEffect(
                telemetry.hasLocationPermission,
                telemetry.isGpsProviderEnabled,
                settings.backgroundLockEnabled,
            ) {
                if (telemetry.hasLocationPermission && telemetry.isGpsProviderEnabled && settings.backgroundLockEnabled) {
                    GnssLockService.start(this@MainActivity)
                } else {
                    GnssLockService.stop(this@MainActivity)
                }
            }

            // Request location (and notification on API 33+) permissions on first launch if not yet granted
            LaunchedEffect(Unit) {
                if (!telemetry.hasLocationPermission) {
                    val perms = buildList {
                        add(Manifest.permission.ACCESS_FINE_LOCATION)
                        add(Manifest.permission.ACCESS_COARSE_LOCATION)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            add(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }.toTypedArray()
                    permissionLauncher.launch(perms)
                }
            }

            val lifecycleOwner = LocalLifecycleOwner.current
            DisposableEffect(lifecycleOwner) {
                val observer = LifecycleEventObserver { _, event ->
                    when (event) {
                        Lifecycle.Event.ON_RESUME -> {
                            hasNotificationPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                ContextCompat.checkSelfPermission(
                                    this@MainActivity,
                                    Manifest.permission.POST_NOTIFICATIONS,
                                ) == PackageManager.PERMISSION_GRANTED
                            } else {
                                true
                            }
                            viewModel.refreshStatus()
                            viewModel.startTracking()
                            viewModel.startCompass()
                        }
                        Lifecycle.Event.ON_STOP -> {
                            viewModel.stopTracking()
                            viewModel.stopCompass()
                        }
                        else -> Unit
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                }
            }

            LaunchedEffect(compassState.isSupported, selectedTab) {
                if (!compassState.isSupported && selectedTab == GnssTab.COMPASS) {
                    viewModel.selectTab(GnssTab.FIX)
                }
            }

            var showSettings by remember { mutableStateOf(false) }

            BackHandler(enabled = selectedTab != GnssTab.FIX) {
                viewModel.selectTab(GnssTab.FIX)
            }

            GnssFixTheme(themeMode = settings.themeMode) {
                GnssFixAppShell(
                    telemetry = telemetry,
                    isCompassSupported = compassState.isSupported,
                    selectedTab = selectedTab,
                    onSelectTab = viewModel::selectTab,
                    onOpenSettings = { showSettings = true },
                ) { contentPadding ->
                    when (selectedTab) {
                        GnssTab.FIX -> FixDashboardScreen(
                            telemetry = telemetry,
                            settings = settings,
                            nowMillis = nowMillis,
                            permissionPermanentlyDenied = permissionPermanentlyDenied,
                            onRequestLocationPermission = {
                                val perms = buildList {
                                    add(Manifest.permission.ACCESS_FINE_LOCATION)
                                    add(Manifest.permission.ACCESS_COARSE_LOCATION)
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        add(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                }.toTypedArray()
                                permissionLauncher.launch(perms)
                            },
                            onOpenAppSettings = {
                                val intent = Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.fromParts("package", packageName, null),
                                )
                                runCatching { startActivity(intent) }
                            },
                            onToggleBackgroundLock = viewModel::toggleBackgroundLock,
                            onBoostAgps = viewModel::boostAgpsFix,
                            onColdReset = viewModel::coldResetGnss,
                            onDismissAgpsFeedback = viewModel::clearAgpsFeedback,
                            onCycleCoordFormat = viewModel::cycleCoordFormat,
                            contentPadding = contentPadding,
                            compass = compassState,
                            onOpenCompass = { viewModel.selectTab(GnssTab.COMPASS) },
                            onResampleCompass = viewModel::resampleCompassCalibration,
                            onSelectSpeedUnit = viewModel::setSpeedUnit,
                            onResetMaxSpeed = viewModel::resetMaxSpeed,
                            hasNotificationPermission = hasNotificationPermission,
                            onToggleLockNotification = viewModel::toggleLockNotification,
                            onRequestNotificationPermission = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            },
                            installedPriorityApps = installedPriorityApps,
                            onSelectPriorityApp = viewModel::setPriorityApp,
                            onEnsureBackgroundLock = viewModel::ensureBackgroundLockEnabled,
                        )
                        GnssTab.SKYPLOT -> SkyplotScreen(
                            telemetry = telemetry,
                            selectedSatelliteKey = selectedSatKey,
                            onSelectSatellite = viewModel::selectSatellite,
                            contentPadding = contentPadding,
                            compass = compassState,
                            compassAlignEnabled = skyplotCompassAlign,
                            onToggleCompassAlign = viewModel::toggleSkyplotCompassAlign,
                        )
                        GnssTab.SIGNALS -> SignalsScreen(
                            telemetry = telemetry,
                            activeFilter = satelliteFilter,
                            onSelectFilter = viewModel::selectSatelliteFilter,
                            matchesFilter = viewModel::matchesFilter,
                            contentPadding = contentPadding,
                        )
                        GnssTab.COMPASS -> CompassScreen(
                            compass = compassState,
                            locationFix = telemetry.locationFix,
                            onResampleCalibration = viewModel::resampleCompassCalibration,
                            contentPadding = contentPadding,
                        )
                        GnssTab.NMEA -> NmeaLogScreen(
                            telemetry = telemetry,
                            selectedFilter = nmeaFilter,
                            onSelectFilter = viewModel::selectNmeaFilter,
                            onTogglePause = viewModel::toggleNmeaPaused,
                            onClearLogs = viewModel::clearNmeaLogs,
                            contentPadding = contentPadding,
                        )
                    }
                }

                if (showSettings) {
                    SettingsSheet(
                        settings = settings,
                        onDismiss = { showSettings = false },
                        onSelectCoordFormat = viewModel::setCoordFormat,
                        onSelectSpeedUnit = viewModel::setSpeedUnit,
                        onSelectDistanceUnit = viewModel::setDistanceUnit,
                        onToggleKeepScreenOn = viewModel::toggleKeepScreenOn,
                        onToggleLockNotification = {
                            if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                viewModel.toggleLockNotification()
                            }
                        },
                        onSelectThemeMode = viewModel::setThemeMode,
                    )
                }
            }
        }
    }
}

private data class NavDestination(
    val tab: GnssTab,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GnssFixAppShell(
    telemetry: com.example.model.GnssTelemetryState,
    isCompassSupported: Boolean,
    selectedTab: GnssTab,
    onSelectTab: (GnssTab) -> Unit,
    onOpenSettings: () -> Unit,
    content: @Composable (PaddingValues) -> Unit,
) {
    val destinations = remember(isCompassSupported) {
        buildList {
            add(
                NavDestination(
                    tab = GnssTab.FIX,
                    labelRes = R.string.tab_fix,
                    selectedIcon = Icons.Rounded.GpsFixed,
                    unselectedIcon = Icons.Outlined.GpsFixed,
                )
            )
            add(
                NavDestination(
                    tab = GnssTab.SKYPLOT,
                    labelRes = R.string.tab_skyplot,
                    selectedIcon = Icons.Rounded.Radar,
                    unselectedIcon = Icons.Outlined.Radar,
                )
            )
            add(
                NavDestination(
                    tab = GnssTab.SIGNALS,
                    labelRes = R.string.tab_signals,
                    selectedIcon = Icons.Rounded.SignalCellularAlt,
                    unselectedIcon = Icons.Outlined.SignalCellularAlt,
                )
            )
            if (isCompassSupported) {
                add(
                    NavDestination(
                        tab = GnssTab.COMPASS,
                        labelRes = R.string.tab_compass,
                        selectedIcon = Icons.Rounded.Explore,
                        unselectedIcon = Icons.Outlined.Explore,
                    )
                )
            }
            add(
                NavDestination(
                    tab = GnssTab.NMEA,
                    labelRes = R.string.tab_nmea,
                    selectedIcon = Icons.Rounded.Terminal,
                    unselectedIcon = Icons.Outlined.Terminal,
                )
            )
        }
    }

    val statusDotColor = when (telemetry.fixState) {
        FixState.FIX_3D -> SignalEmerald
        FixState.FIX_2D, FixState.SEARCHING -> AmberSearch
        FixState.NO_PERMISSION, FixState.GPS_DISABLED -> AlertCrimson
    }
    val statusBadgeText = when (telemetry.fixState) {
        FixState.FIX_3D -> "3D FIX"
        FixState.FIX_2D -> "2D FIX"
        FixState.SEARCHING -> "SEARCH"
        FixState.GPS_DISABLED -> "GPS OFF"
        FixState.NO_PERMISSION -> "NO PERM"
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                    ),
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                            )
                            Surface(
                                shape = CircleShape,
                                color = statusDotColor.copy(alpha = 0.16f),
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(statusDotColor),
                                    )
                                    Text(
                                        text = statusBadgeText,
                                        style = TabularMonoStyle.copy(
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                        ),
                                        color = statusDotColor,
                                    )
                                }
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = onOpenSettings,
                            modifier = Modifier.testTag("settings_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Settings,
                                contentDescription = stringResource(R.string.settings_cd),
                            )
                        }
                    },
                )
            },
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                    ) {
                        destinations.forEach { dest ->
                            val selected = selectedTab == dest.tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { onSelectTab(dest.tab) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes),
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                modifier = Modifier.testTag("nav_${dest.tab.name.lowercase()}"),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            if (useNavRail) {
                Row(modifier = Modifier.fillMaxSize()) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .fillMaxHeight()
                            .padding(top = innerPadding.calculateTopPadding()),
                    ) {
                        Spacer(modifier = Modifier.weight(0.1f))
                        destinations.forEach { dest ->
                            val selected = selectedTab == dest.tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { onSelectTab(dest.tab) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes),
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                modifier = Modifier.testTag("nav_${dest.tab.name.lowercase()}"),
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        content(
                            PaddingValues(
                                top = innerPadding.calculateTopPadding(),
                                bottom = innerPadding.calculateBottomPadding(),
                            )
                        )
                    }
                }
            } else {
                content(innerPadding)
            }
        }
    }
}
