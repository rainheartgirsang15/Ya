package com.example

import android.app.Application
import com.example.data.CompassRepository
import com.example.data.GnssRepository
import com.example.data.SettingsRepository
import com.example.service.GnssLockNotifier

class GnssApp : Application() {
    val gnssRepository: GnssRepository by lazy { GnssRepository(this) }
    val compassRepository: CompassRepository by lazy { CompassRepository(this) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }
    val lockNotifier: GnssLockNotifier by lazy {
        GnssLockNotifier(this, gnssRepository, settingsRepository)
    }

    override fun onCreate() {
        super.onCreate()
        lockNotifier.startObserving()
    }
}
